var GUI;
function newLevel(){
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
try{
var layout = new android.widget.LinearLayout(ctx);
layout.setOrientation(1);

clientMessage("§3Jarvis HackClient made by JudahMan13")

clientMessage("§6Youtube at http://www.youtube.com/c/JudahMan13")

clientMessage("§3Updates will come soon. So please follow!?")

var button = new android.widget.Button(ctx);
button.setText('HACK WITH JARVIS');
button.setOnClickListener(new android.view.View.OnClickListener({
onClick: function(viewarg){
Player.setCanFly(1);
Player.addItemInventory(310, 1, 0)
Player.addItemInventory(311, 1, 0)
Player.addItemInventory(312, 1, 0)
Player.addItemInventory(313, 1, 0)
Player.addItemInventory(276, 1, 0)
Player.addItemInventory(261, 1, 0)
Player.addItemInventory(262, 64, 0)
Player.addItemInventory(297, 64, 0)
Player.addItemInventory(322, 64, 0)

}
}));
layout.addView(button);

GUI = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
GUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, 0, 0);
}catch(err){
print('An error has occured please reinstall: ' + err);
}
}}));
}

