//Наша группа ВК: https://vk.com/club103866091
//При копировании или редактировании каких-либо функций, вы нарушаете авторские права данного файла. Вы несёте за это ответственность.

var GREEN=android.graphics.Color.GREEN;
var BLUE=android.graphics.Color.BLUE;
var BLACK=android.graphics.Color.BLACK;
var YELLOW=android.graphics.Color.YELLOW;
var RED=android.graphics.Color.RED;
var WHITE=android.graphics.Color.WHITE;
var gamemodeon = 1;
var ticklaj = 0;
var ssjg = false;
var spamsendft = false;
var tapaimbot = false;
var spgame = 50;
var enable_script_var = 1;
var tapspam = false;
var tapattack = false;
var helpnumber = 3;
var dasd = 0;
var flyg = false;
var flyw = false;
var basemsg = "";
var antihealth = false;
var antihanger = false;
var hacktick = false;
var hacktime = 0;
var serverl = "";
var numberpackets = 0;
var ddooss = false;
var moving = false;
var moving = false;
var transparent = false;
var trr = false;
var messagechatss = true;
var messagechats = true;
var seehealthmobs = false;
var losat = 10;
var tasol = 195;
var autoenchant = false;
var cheatm = false;
var cname = "Kiellt"
var cversion = "v.9.1"
var dp64 ="ssss"
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
var Button = android.widget.Button;
var LinearLayout = android.widget.LinearLayout;
var RelativeLayout = android.widget.RelativeLayout;
var PopupWindow = android.widget.PopupWindow;
var ScrollView = android.widget.ScrollView;
var TextView = android.widget.TextView;
var CheckBox = android.widget.CheckBox;
var Toast = android.widget.Toast;
var Runnable = java.lang.Runnable;
var View = android.view.View;
var ColorDrawable = android.graphics.drawable.ColorDrawable;
var Color = android.graphics.Color;
var Gravity = android.view.Gravity;
var Intent = android.content.Intent;
var Uri = android.net.Uri;
var GUI;
var menu;
var exitUI; 
var autol = false;
var noeffects = false;
var colorj = android.graphics.Color.argb(150, 20, 20, 20);
var spam2chattext = "[Kiellt] 1";
var spam2chattext2 = "[Kiellt] 2";
var spam2chatzad = 50;
var spam2chatzad2 = 100;
var timeeat = 2;
var blockid1 = 1;
var bhop = false;
var btnon = false;
var criticals = false;
var autowalk = false;
var opnicks = false;
var opnick = 10000;
var coords = false;
var p = getPlayerEnt();
ModPE.langEdit('menu.copyright', '§7@ Kiellt §1| §6Group vk: vk.com/cheat_kiellt');
var bowaimbot = false;
var bowaim = false;
var antiknockback = false;
var kjss = android.view.Gravity.CENTER
var spam3zad = 1;
var checked1gf = false;
var home = false;
var homes = 0;
var passcom = "/login "
var spam1 = 0;
var spam2 = 0;
var spam3 = 0;
var spam4 = 0;
var spam5 = 0;
var spam6 = 0;
var spam7 = 0;
var spam8 = 0;
var spamtext = "[Kiellt] vk.com/cheat_kiellt";
var spam1on = false;
var spam2on = false;
var spam3on = false;
var spam4on = false;
var spam5on = false;
var spam6on = false;
var spam7on = false;
var spam8on = false;
var auth = true;
var spamsend = "/msg";
var lang = "eng";
var showhp = false;
var gamemode = false;
var tppl = false;
var step = false;
var autosp = false;
var tower = false;
var glide = false;
var vsr = false;
var s = 1;
var Xpos = 0;
var Zpos = 0;
var s = 0;
var Xdiff = 0;
var Zdiff = 0;
var sdh = false;
var aus = false;
var wtw = false;
var ttp = false;
var nwls = false;
var eday = false;
var flyst1 = 1;
var wtwst1 = 1;
var sdhst1 = 1;
var gmmst1 = 1;
var glidest1 = 1;
var killaura = false;
var playerDir = [0, 0, 0];
var DEG_TO_RAD = Math.PI / 180;
var playerFlySpeed = 1;
var jtp = false;
var mobDir = [0, 0, 0];
var DEG_TO_RAD = Math.PI / 180;
var color1 = '#FFFF00';
var gfa1 = false;             
var gfa2 = false; 
var gfa3 = false; 
var flyff = false;
var noblocks = false;
var osnovas1s = false;                         
var osnova1s = false;
var osnovasx = false;             
var osnovax = false; 
var osnovasx2 = false;             
var osnovax2 = false; 
var osnovasx3 = false;             
var osnovax3 = false; 
var osnovasx4 = false;             
var osnovax4 = false; 
var osnovasx5 = true;             
var osnovax5 = true; 
var osnovasx6 = false;             
var osnovax6 = false; 
var osnovasx112 = false;                         
var osnovax112 = false;
var osnovas = false;
var osnova = false;
var osnovas2 =false;             
var osnova2 = false; 
var osnovas3 =false;    
var osnova3 = false; 
var osnovas4 =false;    
var osnova4 = false; 
var osnovas5 =false;    
var osnova5 = false; 
var osnovas6 =false;    
var osnova6 = false; 
var osnovas7 =false;    
var osnova7 = false;
var osnovas8 =false;    
var osnova8 = false;
var osnovas9 =false;    
var osnova9 = false;
var osnovas10 =false;    
var osnova10 = false;
var osnovas11 =false;    
var osnova11 = false;
var osnovas12 =false;    
var osnova12 = false;
var osnovas13 =false;    
var osnova13 = false;
var osnovas14 =false;    
var osnova14 = false;
var osnovas15 =false;    
var osnova15 = false;
var osnovas16 =false;    
var osnova16 = false;
var osnovas17 =false;    
var osnova17 = false;
var osnovas18 =false;    
var osnova18 = false;
var osnovas19 =false;    
var osnova19 = false;
var osnovas20 =false;    
var osnova20 = false;
var osnovas21 =false;    
var osnova21 = false;
var osnovas22 =false;    
var osnova22 = false;
var osnovas23 =false;    
var osnova23 = false;
var osnovas24 =false;    
var osnova24 = false;
var osnovas25 =false;    
var osnova25 = false;
var osnovas26 =false;    
var osnova26 = false;
var osnovas27 =false;    
var osnova27 = false;
var osnovas28 =false;    
var osnova28 = false;
var osnovas29 =false;    
var osnova29 = false;
var osnovas30 =false;    
var osnova30 = false;
var osnovas31 =false;    
var osnova31 = false;
var osnovas32 =false;    
var osnova32 = false;
var osnovas33 =false;    
var osnova33 = false;
var osnovas34 =false;    
var osnova34 = false;
var osnovas35 =false;    
var osnova35 = false;
var osnovas36 =false;    
var osnova36 = false;
var osnovas37 =false;    
var osnova37 = false;
var osnovas38 =false;    
var osnova38 = false;
var osnovas39 =false;    
var osnova39 = false;
var osnovas40 =false;    
var osnova40 = false;
var osnovas704 =false;    
var osnova704 = false;
var osnovas705 =false;    
var osnova705 = false;
var osnovas706 =false;    
var osnova706 = false;
var swr = 0;

function poisk(str, re){
return str.search(re) != -1 ? true : false
}


var response = "xex";


var responses1 = "2";

function joingr(url) {
    var r  = new java.lang.Runnable() {
        run: function() {
            try
			{
				android.util.Log.d("URLVip", url);
				var urls= new java.net.URL(url);
                var check = urls.openConnection();
                check.setRequestMethod("GET");
                check.setDoOutput(true);
                check.connect();
                check.getContentLength();     

                var script = check.getInputStream();
                var typeb = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 1024);
                var byteCount = 0; 
                var responses11;
                while ((byteCount = script.read(typeb)) != -1)
				{ 
                    responses11=new java.lang.String(typeb, 0, byteCount);               
                }
				responses1=responses11;
				if(poisk(responses1, "invalid access_token"))
				{
if(lang=="eng")
{
print("Error!")
}else{
print("Ошибка! Вы ввели неверный логин или пароль!")
}
				}else{
if(lang=="eng"){
print("Done!")
}else{
print("Готово!")
}
				}
            }
            catch(err) {
				android.util.Log.d("Error!", err);

            }
        }
	}
    var threadt = new java.lang.Thread(r);
    threadt.start();
}

function replacetext(text){
	var end = text;
	var n = new Array("q","w","e","r","t","y", "u", "i", "o", "p", "a", "s", "d", "f", "g", "h", "j", "k", "l", "z","x","c","v","b","n","m","1","2","3","4","5","6","7","8","9","0");
	var l = new Array("ᶐ","ŵ","е","ř","ť", "у", "ù", "î","о","р","а","ś","ď","ḟ","ġ","ħ","ĵ","к","ĺ","ż","х","с","∨","ƀ","ň","м","¹","²","³","⁴","⁵","⁶","⁷","⁸","⁹","⁰");
	for(i = 0; i < n.length; i++) {
		end = replaceAll(n[i], l[i], end);
	}
	return end;
}



function replaceAll(search, replacement, str) {
    var strochka = str;
    return strochka.replace(new RegExp(search, 'g'), replacement);
};

var sdcard = android.os.Environment.getExternalStorageDirectory();
var File = java.io.File;
var FileReader = java.io.FileReader;
var BufferedReader = java.io.BufferedReader;
var FOS = java.io.FileOutputStream;
var String = java.lang.String;
var StringBuilder = java.lang.StringBuilder;
var MediaPlayer = android.media.MediaPlayer();
var file = {
select:function(dir, fileName)
{
return (new File(dir, fileName));
},
exists:function(selectedFile)
{
return selectedFile.exists();
},
create:function(selectedFile)
{
selectedFile.createNewFile();
return selectedFile;
},
del:function(selectedFile)
{
selectedFile.delete();
},
read:function(selectedFile)
{
var readed = (new BufferedReader(new FileReader(selectedFile)));
var data = new StringBuilder();
var string;
while((string = readed.readLine()) != null){
data.append(string);
data.append('\n');
}
return data.toString();
},
readLine:function(selectedFile, line)
{
var readT = new file.read(selectedFile);
var lineArray = readT.split('\n');
return lineArray[line - 1];
},
readKey:function(selectedFile, key, keySeparator)
{
var isText = 0;
var textR = new file.read(selectedFile);
var splitTextR = textR.split('\n');
for(var i = 0; i < splitTextR.length; i++)
{
var textRF = splitTextR[i].split(keySeparator);
if(textRF[0] == key)
{
return textRF[1];
isText = 1;
break;
}
if(!isText)
{
return '[Unknown]';
}
}
},
write:function(selectedFile, text)
{
file.rewrite(selectedFile, (new file.read(selectedFile)) + text);
},
rewrite:function(selectedFile, text)
{
var writeFOS = new FOS(selectedFile);
writeFOS.write(new String(text).getBytes());
},
writeKey:function(selectedFile, key, keyText, keySeparator)
{
var isText = 0;
var textR = new file.read(selectedFile);
var splitTextR = textR.split('');
for(var i = 0; i < splitTextR.length; i++)
{
var textRF = splitTextR[i].split(keySeparator);
if(textRF[0] == key)
{
var splitWithKey = textR.split(key + keySeparator + new file.readKey(selectedFile, key));
file.rewrite(selectedFile, splitWithKey[0] + key + keySeparator + keyText + splitWithKey[1]);
isText = 1;
break;
}
}
if(!isText)
{
file.write(selectedFile, key + keySeparator + keyText);
}
},
mPlay:function(musicPath)
{
MediaPlayer.setDataSource(musicPath);
MediaPlayer.prepare();
MediaPlayer.start();
},
mStop:function()
{
MediaPlayer.reset();
}
};

var Launcher = {
	isBlockLauncher: function () {
		return(ctx.getPackageName() == "net.zhuoweizhang.mcpelauncher" || ctx.getPackageName() == "net.zhuoweizhang.mcpelauncher.pro");
	},
	isToolbox: function () {
		return ctx.getPackageName() == "io.mrarm.mctoolbox";
	},
	ismcpe: function () {
		return ctx.getPackageName() == "com.groundhog.mcpemaster";
	}
}
var icon = "iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAABHNCSVQICAgIfAhkiAAAGjxJREFUeNrtXQl4lNXVjiCgllUWK1IXBAURAQERCti6VBbFBcWlVouASgsoRa20v9ViaxW1IHVFxKVWZREXxKVVW7XWBSuIFbPMTLbJZCaz7zPJzLz/ez7O8ARKMJl8E0LDPM/7PEqSb+49771nu+eer6CgFX1QUNCJ6E0MJc4nfk78nniCeJl4n/iSsBFOwk9EiYQiRgT0Zzb93ff1b5/QZ/1cnz1Uv6tTQVv/UAgHER2ILsSRxABiGDFBhTWT+BWxnPgz8TrxIbGVsBAOwkuEiTiRJGqVlLD+zKG/u1X/9nV91nJ99kz9rgn63QN0LF10bAe1JUJkwt2JQcRUYgGxjFhDvEN8RmwjiokyFa5bd0RYd4KQUEekiLQipf+W1N8J69+49Rll+sxt+h3v6Hcu0zGcp2PqIWP8XyagHXEI0ZPoT4wmphDXE/cRG4gtRLWueLQQ4vqdW3QMMpYbdJGM1rH21LG3+18iRCbUlxinExa1sZHYTBQSdl3JcV3lLUVISr/Tr2Mo1DGJentQxzpOx37I/m4jDia6EscQpxGXEIuJF4kvVM+Lmsm0IAHfhoyOyatjfFHHfInO4Rid08H7lY3RAXcmTiKuJu4nNqnuLid8quczrZCQjI7Np2PdpmO/X+dyks7t4P3FWHcjjicmqo1YRXxKeFohAY0lyKNzWKVzmqhz7Naqjb8OcJiupJXEP4kSVQGJ/ZiQhM6hROe0Uucoc+3WGu3FYUQ/YjwxV1fSdnU9U/sRAY1xAmI6t1U61/E698P2uV1RMtqrsbuUuJf4m0bJQZ1A5n+IkIzOKahzlLkuJWaoDNrvM1I0thCP4wTiYnVlP9QgDG0EblVhD6oMTlCZtNsXZHQkBmtu6Fl1E92qb9sKIQmd8xcqg5+rTDq2GCmqpiTtcbIatueJb3Qbo40iqDJ4XmVyssrooJYgQ1zbIcQi4iWNboOa3GurhNSqDApVJotURvlLUioZXXVLyipYr4Yt0oaJ2B0RlYnI5icqq66mk1LPmzqRmK8phUIdQN0BInaiTmUisnmBmKcyM9f7Uh/7GPUkniOKiNABAhpESGX0nMpMZHeYmYT00zjjQU1Vh9q4zWiMTQmprB7UOKWfmQdJ4zXoa2txhllxylKVYfdm5b70AcOJn2lU2tbiDLPilHdUhiNEps05z5Bz5muIJ9V7aNYA00TdQQch3rEjwl27InzkkYgPHIjkkCEG4gMGIvzd7yLcpQsSHTqgTv8mXwLL6POT7dsjcuihCPfsidixxyIxaBCSJ52ExAknINK3L8LduyPeqZMx9hzHI7JbrbIc0OTzlHqHSz/Qao3tZgR+MqEwJ+86/HBYTj4ZlqlT4brpJviWLIHvt7+Fc8GNsEyeDOvgwajp1g0R/n5dHgkxyCD8hx2G0n79YBk7FvaZM+G+7Tb477wT7kWLYLvgAliHD4erd2+EZZFwTDkGjttVlj/IHnI1NY0+VLfZR83N2qaIRLt2CPfoAf/QoaieMgWWuXNhue8+uF5+Gb73PyDeh3PDBljuvReWOXNQffbZ8J14IiLcScncV+aeFwbHEuUuDXFhBLlDa8aPh+3yy2FZvBj2Z56B+6234P/HP+B+7TXYli2DdcECOElMYMQIRLiLZEelm0ZMNkv8kcp0aJPS9vzlY7VM5mktpWlW1lbIqOGWr+aEfL/5DUIkIfivfyFcWIi43Y5kTY0B+e/wN98g8MEH8Dz3HFwLF6KaqsPLlZnMbWXuEUJGBQVrPW00qihs98qV8P/tbwhv24ZYaSkS1dXGeBJVVYgUFSH82WeIvfEGwr/7HdyjRsFL9Sak5JAltqhMRbbHNoYICWAOJU7X0pjP9SgzZx0tu0NWeRVthH32bAS5+pIuF9LxOBr61EUiCNtscK9bh8orr4SDqzjaubOxSzK57FCSGRM7wWdEqZp8p45A2XnnwXbLLah+6SUEuAhqg8EGx5NJJpH2+RB95x04Zs2Cgyo1RjuXg0x8KtNlKmORdfu9EXKoxhziN7+pp2TJZqkqIkSBOrkSa9avR8xqNcjIpFINCiBdV7eDlK+/huOppwwhhI47DrU5Gnkhw/Gd76CURrp8xqVwcKX7Xn0VkS+/RLyy0iAjXVvbMCHptEFKrKQEDqo0GU+M48lBJkmV6ZvZ2ERkvjdCemkl3/8RXzX3yDVJVeWnenCPGwfP6tUIckK14TAa+0n6/fBu3QrnihVwjxyJAAVb2wjVZSwE/l6UqiXSpw98XNGVZ56J0uuuQ/kjD8P1wfuIUyU19ZPgeDwcj2f5ciRo6JtxJPyVylhk3WtvhAzQ/IskxyqbS4jo6nIaztJp0xB4+22DDFn9jf2kuSqFFP/GjbCdcw7K6A1FGqG7hQwP7U7lUUfBRueggt6Sb80aRD7/HFFLiUFGKpFoMiEpjkdISdAGprjImkFIpcpYZD1gb2l1qT16SEtfAs01nqKzbQMGwEbbEdm8Gbl+wp98AuuPfwwrBRzmqt9jfCNEkIQI3WUfYwnnmDGopOdku+suVFE9xWigTfv8/e/AGWc0RzYBlbHIesx/HWgpGT20hHKTVvIlm0tIrFcvOCZOhIOeVew//8l5/jHqescvfwkHhRzjjvsvN1bI565w0622DRuG0quugvexxxCh6xr+6iuDjFQs1poISaqMN2nB9+FCSn1CumiR8fVaSmlKRWGCkXjN+eej5oEHkKD72NSPGNokDW7oo4/guvVWwxYl6K5mI+xa8ZyoxgKM7n0MNJ2TJsE6bx7KV61CePt2pEnC3pyHfUhItkLyc41LpPiua31CjtTdsVSPIk2pn0r07QvPhRfuMILFxU2et5Dho0tazZjEQfXjoZeUUPdXPK6AeE5UT5ZJ58K15Lfw04uT+CZKl7mOfytkZDKZ1kpIRlP0fyQukPrh3Y35fD1+rDQrAEtQ53suugieBx9sFCEiQDG2CY8HIRLhpd/veuIJOG+8EW6qKx89pgAJCVI1hWib3BMmwHoVbcsf/gAPI/2Yw2GuatqTUfd6kWDskho71gwZVRGvEguJgfUJGabByhbVbeYQ0sQdImTE3G64ucqL7r0XxTTkIvQo45g4bYeQUdqrJ0pGjYR9/jxG2I/DT9Ikuk+I55QvFZV1e0lGDaP2mqVLkTjlFDNklDXuKySrXv8amfjDa82+n/FthIg6EQHWhkIIl5bC/+mnRsBWfffdKJw8GUUMvmoYEYdJREQi7BEjYJs6BZabF8Gxfh0C27/ea4Rt1kdc9VoGqkE6CBV0FirpNESPPtqs+ykudYHPMK486D07sfTvmn0/41sJURUVoMG3PP00ChcuRNXUqfAMHQofDbWHZFSRjHKqp4oZM+D4/e8NwsIMzmKNiLDN+ggZAdol59q1KL3sMtj790eM9svE+ynvEReKLS/QzONMveJlanq7IULqqFqidEVlxYWo+2toJ4pnzsQ3jMYl6edmrBGgvfAPGgQHjWfFrFmofOQR1Hz4IRJUafn+SKpEdkUyEEDYYoGX3+sSx0IWDKN+98EHG8GnibISz3YOcaoQMk0vQW5rKUKEjPLXXkMxg7Yyek8SX3ionry0E06SUUl32XbWWaj4xS/gf+EFRKm3oyUlBhm5RNi5qKi6aBR+xk4lVFHfzJ2LinPOgfvEExHq2tUgI2WurCSVcrsURBRo+L5cL0OaSkiSXpb34otRc//9CFKoEdqJ8L//Dc+aNbAtWoSis89GKX+niiR4u3eH/5hj4B49Co4Zl6J0yRLYJcK22ymhtBicPG6JjAEhIcrvCzIQDb73HlzclUVXXIEiOcPh+EIkojY/h2VyzeFPxI1CyN1arlJmOiFiiC+9FNXU/ZWif595xjiYKvvhD+Hh1g8ccQR8JKOabqyFXovtyivhfeRhRN57d8fZRDbCVoHlm5Ao7VL5hg0ovuMOlInNOu00eLhIQt26Id6hQ87Z5kZAbmr9hfhDgd5z2KTXhs0lRDKtVD3V116LyptvRinthIVElNFYu7n1gzTcIUbY7nPPhe1nP0PZ448jRDWRikaQaUISMue4Ih5HzOVCmOpUDqE8VI+2m25CMRdMOdVmHmxFQ3AoB6sKtMtBXsp7koccAp9MjF5SUI5jGVWHlQwrbYZ10iTU0I4EGWhJhB2xWlFLQypkiGHN90fIqHr3XVho4yxcNOV0IDx0JEK9eyPKsefBVuytXEg4eKWgXrsKv9lfJGcXofbt4ed2D3bqhAhVU5zkBBjslTLos91zj+HBxKurjdWa9x2h6fNoeTlCW7bAQ/VUTvVkuegiWI4/3rBlsaYdzZoFv3LwQYFa+LwUTaeVFCGj4vAeKGWEXT1/PrwrVyLACDvCCDspntO3nCCaFmmTDDdjmPLnn0cxVZPsUM+wYQhLWp9xhZCRahkV1VCR9lcFalCc+eigkOnYESm6suFBJ6KSdqKUEXZjzrDNjrBj3IFimzxvvw3HQw+h7LrrUDR8OMroOUW4e1tBQV22o0RZgeqvQD5qdYWMOD2VyA03IEyDGeHqjLdwhB0qK4ODRBTeeSeK6Dm5xo5FkJF2UMmo2zc7oqGzdmeBbpe8tLRIMTCMX3AB4suWIZXDeUguEXY2Ixui5yS1XlJOZF+8GIX0nCxUTQHaiXxXROZ4jcFolFNQr6OO6bdlM0cfjdRVVyG1ahUyNlvLGG2fD57Nm1FMz6lo1iy4zjwTQXpOAak8JBlyqJVrOVGer1tLHXC0IJ9flKGbm2HskWFAmGGUnrcIm6opQs8p8PnnCGzaBOf996OQnlMhXe1qBnWBww5DmLs1Sg8vzn9LcqHU0oiLAW8lxKTVZCTzSwij3Mw11yDz1FP5IySdQqSsFDZ6TkW33gr7tGlw02D75HCMZDhIRgUXRtmFF6Jy3jw4b7kFXu5aqfOK7zuvaq+E5E9lCSFXX43M6tWmqqw6uslRek5yMBX5+GN4nn0WluuvR9Hpp6OCqsnFoM5Ph8LH2MI5bhzsHEM57Vjl+vVwvv46PI8+Ct/06QiecAJieagdbobKiuXVqOeLECGj4s03UXLvvbD95Cewjx8PD9WRr2dP1Ei2uFcvlNC7K50zBz7uzpicsxcWGrmquMOBKL09H9Vozdy5qKEK8x98sKm1w80w6oG8ur1mESIp97jHgwifYWSL161DKT2n4ilTYKU9qKQ98HTrDn+/fvCeeiqq5QoBVVM5Payo1cotVbcjY5x1h6WS5euvDQ/MSULdJ59sVLXXkpj0viEm2w7Kmd/A0CRChAwnVVMpvbUSrurSs8+C5+QhRnJSDLaLZFgGnwTrJZcYZy/ht95CiMRFGYPUSenqbul7iYGElBh3jf+VV+AhuZ7RoxGk+hJS9nVgmLfUSa6EGKd1FKSk30PbtsFDvW9fuhQ2GuPiwYNh69YV7i5dEOrdB+FBg+E98yxYZ8+B7U8PIbBli1EC1JjAMxWNIlZRgeAbb8B7443w0t6EjjgCcZLSwsZ+l9RJ3pKLuRIiZPhLSmDfuBFFXL0lVEGeUaMQpnoKkAgnYfne92BhsOfkz/1UPXKnJCLF3H6/QUZjssWSVRZSkiQlxiDSf889cDCSd/H58ZbdKbskF/OWfm8sIUaxAz0nOaINUY343nsPNTTGlYsWoZACsvbpgxA9JzG8UmxdI9fPpk6F5Y474KJ6kooViUVyznkxoKwjkRGSWn3zzaiikyBuc6xTJ6TatWvx9HveDqgaS0j2oKjmo49QRNVUJIb2jDMQolsapLEVMqJcscEOHYy4wv7978P92GPGUat4TUJGuhkHWkZRA0mpdToR+eQTeFasQPk556CK6ktIaekDqrwd4TZEyC71WPx3P4Xge/llo8ynkJ5TUf/+cMqJYufOCHM3RBhPxPis4JFHorp7D0OteCk08biSFKJ4YWak77MqTJ5rv+suVHIXBgYORIIqLJVfFbbLEW7eihwaJETrsYJUT9Ynn0TR/Pmomjx5Rz2WnDCSDLtUKTK2KJWzbQZ9kcsvR+2ECYhz1fqpwiq5S0SlyeVMKT01oxrFuCklFSc+n1GtH/jzn+GS6kk6EoncrrDlVOSQtzIgI5f1058i8/TTRuokW48V+s9XCH/wvnHZsoSEFQ4fjkpG1m6qJkkCyu1bqccqnz0bpY88AgcJjf361wCNO/r23XlFrYLBn5u7KkSbkygvN6+U1EjJpJGgkyCq0ckx+hmrxLp1Qyo/5ye7lAHlrVAuc9xxyFCoGXpBGcYEO+qxXkXJXUtQzhVfPWYMvCTN16OHke6o5Oq3TpyI8gUL4PvLXxD99FPDc4rRtqToAWHaNIOQ7CXOIHeKFGG7ucMCjNylZMiUYmtNWqbo7SUsFqOqvmLmTNi5g4WUPBCyS6Fc3kpJ03RNay+7DHEKM8wAzL3mRaMeq5iBXelRfQ0D7SUZAao2cWsd06fDdvvtRs4pSld0Z0AnZyl//ONOQnae2VOvSwG2XFX2cAf5pcx0+3YjBS+peNOKIahu7QxKy7nb3UOGGDfD6syxKdkc1i6lpHkrtq4VD2ncWFSffz4shJVxg9uox+qzox5LOjpIAbXceHr4YUSkkn3rViPnJEVrO+uxhJAHHvgvQiTNIaRI2sNzyimo5nPstEk1X3xhkGLaOYscA8s17bVrYb3iCpTRtgkpJvVCqdml2Dqf1xFquQNCVEnVA46HpXcvWGkYa+rXY02aBBvVTRlXn1GPFWmgHqsBQnZ+D2OFYMeOcNFNrrj2WlTRNgVJStLrNdxZsz7SREA6O9guvNDogWLidQQx6CPyfmEnLdeYSUq883cQ7tTRIGNnPdaSJTvqsT7+2Ega7rUe61sISSspERLukZT7RRfB9eij8G/ebJBi1ifJXecn0X6qz+SwYWZd2HmN+IW0mM37lTZRKUl6JXHaiUS9eizjxhOj4lgj67EydI9T992HFOOCDN3iBnuYyOVPuRsv90roGbmpBoOMceISq5hQ92XceWTslHztNaTpdpt0pW3Znq60ddGGjTeYeelTyPAykHOOHGV4Qt4nnjDqsXbeeGpkPVaKhjp2992I/ehHSNET22v7J6m6lws+Uk1PAqvoULj4nUKKKdcUSEr6r39Fht6giZc+h+x+6bOjXs09z8xr0XGqq2rakIqLp8P57LM512Mltm2De/HinbdwG1Wgx50SYpTvoJqrYtQt9xXFczOchf3gWnS2U7WpjQNiVFVVI0eiknFF8MMPc67HCkkVyZw5KB44EKFGeDc7r01Law3aHPf4CbAtXIjyF1/c4U639sYB+WqtIUGUncbPTkJiNIZNvVZg5LyoJoIMDL+59FJ807uPUZba1G5EocN7ouz0sbBxHJ6NGxFjkJrKITucHU/m3XeRyY2QxrXW2EPzmdvNaD4Toytqp4qxM+CTaLvJhGhuKcIVWTFpMiqoAqNNKIbOKGo5jghJ8dCWld8wF1VUn0JKrlnhZtiQJjefMbU9k5Tzyx2LasnOPv204d425dyiTrLBdHnFGXCdNgZektGcYoQYHYyqU0ei4vrr4duwAXGLxfgOY+U3YqFIdjrE8YQefxy1VMUt0Z7J1AZm2TZJXno8lmuugW31UySl8fVZcuHS+thjKLn8cniPPrrZ5TqSGBRSfIzqq+gWVzNWiRYXI9XIjg9yVGBlEGu96irj9DLvDczy1eJPOvRIU5jiWbPhemkDwnLUyiArLecYEkmLoZdjV1EHdIWT0smBK9G5Zo1xWCVNMcMmpr/jcgzMZ9qvvBLuZ55BUIrA5aBL2kdJGr/eeDL8fzkWDlutRk9IKU+1ktBw05KMubX4y1cTzDquTJmAkxMp/ulMWBmwSdlnHWORNCcLcYXFAyNJSQaLXkbvxYzMC6+4wui5KGTUmXhAJIdNQoqXUb313HNhue02uN980ygZkjFlx5Ph2FJcHFI4YXl8JQpnz4aDCyvIudQ2LQ3f7CaYpraJzbqh0qvXNmQIrDNmIECB161bh/TLLwOvvmogzRWYfOEFeBnJF58/DSUDdri5mTwVR0do7MukGSZtnLSGja5ebYwpO57MK68gtX49AnLljbvJomSkmj6eZreJ3b2R8urmNFLOClRWuTTElGPZWk4uTUFkpDObpCEI+e/0mDFIDh2K0JF9jZYaks3NFyHSLlZIkQbK0jy5btQoY0z1x5Ph/9cOH27YjLDujBzG07xGyru1Gh+h2+ydA63G91Gr8Qaa8S/VxvIHmvE3rbznI9Oa8e/2uooZB15XkdPrKlaY9rqKPbzQZfqBF7o0+YUu0/PxQpcDrzxq+iuPXlRZmf/KowMvBcvppWBX5+2lYAdem9cKX5t34MWSrfDFkt/y6tUtaLuvXt2CffXq1b28nHiF+tzuNhhnrMC+fDlxA6/vnqEBUFt6ffc7aC2v7z7wgvtW+IL7BtL2w9SwrdRUS4mekiXMqvdq4R2R0bF7dS7/1Lldra8U7F7QWj/q5gkpxxMTtbm/vHLvU8KzHxPi0Tk8qXOaqHM0JzfVAsRIermzdv2XlfQA8YaWvpTrUWayFRKUHU/23ni5jvkNncPVOqfOTTrPaAWEHFTvkOsYrT26RC8GSUrhC1UB6VZISFrH9oWO9Vc69jE6l645n2e0IoLkMP8oYpyWq8oVuo1atirRrV0r+eIt7ARkW337dQyFOqbXNbN9g475qL1Wh+yHhGSrWXoS/YnRxBTVx/cRGzS4MvV+SiM7KEgXi606hvuUhKk6xv465sZVh+zHBGUPvgbp5Bdoacxavcn1meruYr0d7NAgzK9NWuKq5+tUxdRHnf4snu3Spn/r0GcV67M/0+9aqzt2gdY2D9LXP3UoaCufeknKLnoVYoC6yxP0Euq1qruX65nCJnU3pduBVXeST7OrWWKyRET0Z9X6u1/q327SZy3XZ1+r3zVB3dcBOpYuLZIU3E+Ikut1fYhTVFjz9B69uJuvSOsJXd2l+t6NoO6EWkVc/82lv7NN/+YVfcbd+sxp+h3yXZ1akwz+H+h/Wmwl+ntJAAAAAElFTkSuQmCC";
var icon2 = "iVBORw0KGgoAAAANSUhEUgAAA8AAAAHgCAYAAABq5QSEAAAf5klEQVR42u3da4zn133f9885v99/uLtcXpaiSFuSXTl2XZG620aU2FT1pE5hyZFJpnDdQkALuEVaC6SQoPWTNi3QNkDhFggEIWiS1kAiBI1cGKRs1HHqXh5YrGW5diWKlyUtKfWVNJfLnd2d2dmZ+f9+5/TBzFAj3sTLcrkz83o92Z3L/7K/P5+8+T2/cxIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOrXKQ3mvv3ScGAABwLYVaKUki1l6P3nvpvdfe+9B7Hy9fvrzovVdXBgAA4JrtuLrbbuNuy9Xe+zU3cC3XwIUqu++jJumllPllfrX+6I/+6Mrdd99db7/99nrXXXeVO+64o/hPDQAA4Oo5ffp0f+ihh/ozzzzTvvjFL7Y/+IM/2E7SXqb3ht3ea7u995ZOit+SgNyN3pokLwze3vsiyTuS9t7t7emHVlZWbknyr/Te37d5efPW1ufres/KOI7DOI61VsNhAACAq6G1lmma2jRNcynZrmXYOnb82NlSyqNJ/nh7e/vcysr4zaQ+luSpUsryJYI4SdpbEcNXNYB3lzKX/dHbez+W5L1J/kqSDyX58Xluf2kY6jH/eQEAABw889w2h6H+yyS/k+RrSX43yWOllM0XxHAvpbRDE8D7pr3PF37v/XiSjyb5RJKPz/P8l4ZhqPsek3mee2ut1Vpba6303mspZe/59m60BgAA4Crb26C4lNJ77ymltFpr30m4WodhKPubbZ7nNgzDv0zyz5P8RpIvlVIuv1wzHsgA7r0PL5j2/uUkn0ry8SQ/uPf95XKZeZ7nWkvf+YeXvfuChS4AAMABC+MkPek9SWutl2EYhsVisf9Xv7Ubw/+0lPJ7L9eQByKAd6e1feevvWZn0vsfJvmpJGOSXL58OUmmJHX3fw2Ug3UqEwAAAK+iEHczcSeIk4zHjx/f++GU5DeT/I9JfmN3OXTpvZc3Y2n0FS3OvR2d995o7/3eJL+Y5CN70dtam0sppdZS38QGBwAA4NqM4bTWW++911qHfTH8lSS/VEp5YLcn904KumLLoq9Yfe4fVe8udf47SX46SdbW1nqtpZVSdzfB8rEDAAAc6RTueynZWmu93nDDDXul+L8m+a/3lkZfyWXR5cq88Z031Ht/W5L/Isl/kOTEhQsXW60lzioCAADglbTWWms9N910Y02ykeR/SvJflVKeu1IR/IYCeN+OzL33fleSzyX50IULF/rOLmBl8DECAADw6kO4z733etNNN5XsHKF0Xynlof39edUDeHejq70blH8xyX+2tbV1w8bGxlRrHWst6d2HBwAAwGuI1JK01tNam06cODFed911a0n+binll7K70fLr3SDrdQXwviXPNyX5h0n+7YsXL87zPJdhGKrwBQAA4I2G8O75wf3GG28ckvxKkr9ZSrnwepdEv+YA3he/70jyT1qb/43z588vk7Kote4/9wkAAADeQASXtNaS9OXNN9+8qHX4P5L8e6WUp15PBL+mAN4Xvz+c5J9ubW3/2NraxamUsrC1MwAAAG+G3nt678sbbrhxvO66ld9P8qlSyh++1ggur+EF9+L3X03y4MbGxh3r6+ttHIfRxwEAAMCbbZrm6eTJk/XEiROnk9xTSvnGa4ngVxXAezcZ996/Zzd+f2xt7WKGYRwteQYAAOBqKKVknqfphhtuzIkTJ35/N4L/4tVujPVdA3hvq+kkNyb5Z5ubmz+5urqaYTD5BQAA4Oqb53k6depUjh079r8n+XeSXNwN5P66A3g3fuvul7+8vb397549e7aIXwAAAN7qCL711lv7ysrK/5zk53e/3V4pgr9bAO/d93vfcrn8pWeeeWYYx3GRWPYMAADAW6lkmqbl7bffPi8Wi18spXzuu90PXF4hfvfu+/3LSR44c+bM25fL5YrdngEAALgW9N6zWCy2b7vttmeT3FtK+b1Xuh+4vMyT7H3/piQPPvfccz+xvr4+juNYYtMrAAAArgWlZJqmfvLkyeltb3vb/53kniQXdn704qXQ48s+zc70929dunTpJy5cOD+srKyU3psLDAAAwLWh9wxDLRcunB+OHTv2E9dff/3fKqX8l733mpe4d7e8+PHPL31+X5Lf+KM/+qN3lVJrrS/56wAAAPBWVnBaS3pv7d3vfvefJflEKeXRl1oKPb50RPeS5G+fOXPmXdM0lcVi0eeWYvMrAAAArjUl6dM0lTNnzrzrtttu+9u9959/md/7jvDd2/X5r21cuvSFP3/qqZsXi8XOfb+GvwAAAFyLepJSslwu+zvf8Y7zJ66//udKKb/1wl2hXzgBbr33IckvrJ4/d6r03ntr335CAAAAuCYjuKf0ntXz506duP76X+i9/59JXnoJ9L7p74+vrq5+bH19I+M4ptn1GQAAgAOgDEPW1zeyurr6sVOnTv14KeVL+6fA+yfAe2X8qY2NjZtba733Xkx+AQAAOBgFnNJa6xsbGzefOnXqU0m+tK91dwJ4387P79na2vrE2sWLGYaS1mYXEAAAgIOhJ8NQsnbxYrZuvfUTvff3lFKe2GveMUl++7d/e2+Lq79x9tln3zm31uowVsNfAAAADpKSUuY2t7PPPvvOd77rXX8jyd/da96x91527/1dXLp06ROXNzdTSsk82/kZAACAA6YnpZRc3tzMxsbGx3vvv1RKWfbey5ikJpmTfPjZZ599/+bly6m1lt6bCwcAAMBBrOCyeflyzpw584F3v/vdH07ye0nq/k2wfnKo9WRvc0ut1blHAAAAHFClt7kNtZ5M8pO7AZxxd/nzcGF19eOXNjbSS81s+gsAAMAB1kvNpY2NXFhd/Xjv/b8tpcx7E+Afevrppz+wPU27pWz6CwAAwIFWtre38/TTT3/gplOnfijJk3sB/OFhsTg5Xb7chnG0/BkAAICD3r9lnqZ2/Pjxk0k+/HwAr62t/chiMSS9994sfwYAAOCg60nvfVwMWVtb+5EkXxh77/Vb3/rWX1kul+mlFKufAQAAOBQJXErZ2tzOs88++5Heex2T3L6+tvae3ntaa6UWBQwAAMDB1/rOcUhbm5t3JLl9fPLJJ+/Y3Ny8Zaw1pZT0LoABAAA4+EqSebnM1NotTz755B3j2bNnf/iGkyeHjcuX+zDU4hIBAABwWBp4aq2fOH58OHv27A+PJ04cu32xspK+sdHm1gfXBwAAgMOi994WKyvDiRPHbh/b1H5gnlrSe2IHaAAAAA5XAWeeWtrUfmC8uL7+vpuHIa23UlNdHAAAAA6N1ltZLrdycX39feNyuXz7NM9prZdUE2AAAAAOUQC3XqZ5znK5fPuY5HhrLa21FBNgAAAADlUA7/RukuNjej/WpimlpzT3AAMAAHCIlJ7Spinp/dhYh7oyt5ZenP8LAADAYSvgZG4tdagrY63DYprn9PSdnwAAAMCh0dPnObUOizFJbXPbbV9TYAAAAA5ZAveelNSxt5ZStC8AAACHOIJbMrbexS8AAACH3ti7+gUAAOBIBLCjjwAAADgSAWwCDAAAwBEI4CaAAQAAOAoB3Jsl0AAAAByBAI4JMAAAAEchgGcTYAAAAI5CANsECwAAgCMSwC4CAAAARyCAW5tdBQAAAA5/AFsCDQAAgAAGAACAwxLAbRbAAAAAHIEA7nEMEgAAAEcggFsXwAAAAByBANa/AAAAHIkAjk2wAAAAOAoB3JoRMAAAAEchgE2AAQAAOAoB3E2AAQAAOBIBbAIMAADAkQjgCGAAAACOQAC32RJoAAAAjkAAWwINAACAAAYAAIDDEsBzn10FAAAADn8Axy3AAAAAHIUA7s0SaAAAAI5AADcjYAAAAI5CANsECwAAgCMRwK2ZAAMAAHAEAtgEGAAAgCMRwCbAAAAAHIkANgEGAADgSARw9C8AAABHIYDnNrsKAAAAHP4AtgQaAACAIxHAEcAAAAAchQBuswAGAADgKARwHIMEAADAEQjg3gUwAAAARyGA9S8AAABHIoBtggUAAMBRCOC5GQEDAABwBALYMUgAAAAciQDuJsAAAAAchQBuJsAAAAAchQDuzgEGAADgKARwaybAAAAAHIEAdg4wAAAARyKAW59dBQAAAA5/AHcjYAAAAI5CANsDCwAAgCMRwLNNsAAAADgKAewYJAAAAI5GALsHGAAAgCMRwJZAAwAAcBQCWP8CAABwJALYEmgAAACORgC3luI6AAAAcIj1JOM0zalD3fkKAAAADpuStLllnKYp143XpVkKDQAAwCFUS800TRmnecpKX0nvRsAAAAAcPr33TPOUcZ6m9NbSpymp7gYGAADgEGk9fRwzT1PGeZ6TlPRSYggMAADAYVJKSVIyz3PGra2t9JJMraXYDxoAAIBDpKenjsnW1lbGzc3N1CSZ56RWVwcAAIDDo7XUJJubmzsT4NbazilI1kADAABwiPQkrbWdCfDW1lamaU7rXQADAABw6EzT/O0AnntLLz1xFDAAAACHSU3mvm8CvNzayjiOab1lZ0AMAAAAB11J7TXLra2dAJ6mKWtrazl16pZMU3MUMAAAAIdC6z0rK0PW1tYy7Z0DvLZ+KW+79dbsbBCtgAEAADgMeupQs7Z+aecc4FJKLl3aqeHemwXQAAAAHJb+zTRNuXRpLaWUjLXWXFq/lGm5nd67W4ABAAA4NKbldi6tX0qtdWcCvFwuc/HiWm666eYsl8tYBQ0AAMCB1pPFYpELF85nuVxmsVjsBHDvPaurq7nx5psz95baFTAAAAAHV0vPWJLV1dX03neWQPfeM45jLl68mGl7K8NuEKdbCw0AAMABVEqGUjJtb+XixYsZxzG994xJUmvNcrnM2tql3HDDDZnnyQUDAADgwBrHRdbW1rNcLjOO48739n7Ye8vq6mpOnrwxre2MhwEAAOCg6b2n97K7/Ll9O4r3/rJYrOTixQvZ2trIYrHIPDebYQEAAHDA6jcZhpqtrY1cvHghi8XKiwM4SeZ5zrlz5/I933NbWptdOAAAAA6ccSw5d+5c5nlOrfWlA3gYhpw/fz633HJLSi9paa4cAAAAB0ZNzfb2lPPnz2cYhu8M4xcG8Pb2dlZXL+TWW9+WaTmnWAcNAADAAdDTMy6GnD37XJbLZVZWVnZOOXqpAO69ZxiGnDt3NidPnsgwDGndFBgAAIBrXy0lm5uXc+7c2QzD8B3x+6IATnaORJqmKefOncvtt9+WeeleYAAAAA5AAC/GPPvszr2/e0cfvWIAJ8k4jrl48WJuuOHGLFZW0mYRDAAAwDUcv8OQjY3NXLx48SXj92UDONlZDn3u7HO57R23p5eedBcUAACAa1BJelqeO/vci5Y9v6oAHscxl7cu58Lqam6++VSmeUopNsQCAADg2tF7zziOOb+6ms2tyy87/X3FAE52doVeXT2flZXrct1112We52hgAAAAro343enWjY2NrK6ef8X4/a4BnOxsinXu3LncdtttKaWmtSaCAQAAeMvjt9aaeZ5z7ty51Fq/62NeVQDvPeEtt9ySUpLWWuJ8YAAAAN6a/E2tNb23nDu3s+vzFQngvQje3NzM6upqbr755t2biu2KBQAAwFuUwL3n/Pnz2dzczDAMr+ox46t98mEYcvny5QzDkJMnb0jvc1qL5dAAAABcpehNak1KGbK2tvZ8o75a42t5sWEYsr6+ntZ6rr/++vSe9N58CgAAAFwFNa0lly5dzMbGpdcUv685gPci+PLljfQ+5/rrT77iGUsAAABwpZTSsr6+ns3Nrdccv68rgJO9e4K3np8El1LsDg0AAMAVt7fbc+896+vr2d7eflUbXl2xAN6L4O3t7bTWcvz4sQzDIvNsOTQAAABXTq01y+V2Ll/ezDRNrzt+k6S+0TfSWsv6+qVsbW2llJKd45EsiwYAAOD16klKSinZ2trK+vqltNbeUPwmb2ACvF8pJZublzPPy1x33bGUUtL7nN7tEg0AAMCrzN7dhiylpvc5m5ubWS6n3WHrGzdeqTdaSslyOWWaLmWxWGSxWKT3HntkAQAA8BrqMtvbW1kul+m9X7H4vaIBvBfBSbK9vZ15njMMQ8ZxtFM0AAAA37Unp2nKPM+Z5zmllCsav1c8gPe/8dba82+81ppa6/NvXg8DAAAc9eDNbh/2tNaeb8g3I3zf1AB+qRDei+Baa0otu/tkWSINAABwtKJ3J25b+3b47hyr++aF71UJ4P0h3HvPPM+ZpinDMKSk7P27d3++/xGqGAAA4IDn7neE7/5bY/f6cC94y1XaPXm86pdgdyq8/+tv/2nLaAAAgMOhP/9na/358H1hC15N41t+Sfp3XogXXwRRDAAAcLCiNy8K3mvBeM1drhddIMuhAQAAeOOqSwAAAIAABgAAAAEMAAAAAhgAAAAEMAAAAAhgAAAAEMAAAAAggAEAAEAAAwAAIIABAABAAAMAAIAABgAAAAEMAAAAAhgAAAAEMAAAAAhgAAAAEMAAAAAggAEAABDAAAAAIIABAABAAAMAAIAABgAAAAEMAAAAAhgAAAAEMAAAAAhgAAAAEMAAAAAIYAAAABDAAAAAIIABAABAAAMAAIAABgAAAAEMAAAAVzCAS8m2ywAAAMBhVkq2a29ZLztfd5cEAACAQ6aXJL1lvbb09ZTikgAAAHA4lZKWvl5LyZqrAQAAwCFv4LVakvXdry2BBgAA4LDpSVKS9Zrk6VqrAAYAAOBQBvBu8z5de8s3SpLWmssCAADAodJay+4mWN+oqfWbPUndTWIAAAA4LGqtte/85Zu1lPKNaZrmZCeKXR4AAAAOiZ6kTNM0l1K+UevW1jfqMFwqjkICAADgkCmlpA7Dpbq19Y36yDe/+VQtOW0jLAAAAA6ZXmtNLTn9yDe/+VRN0nrKQ6WUNDthAQAAcEi01lopJT3loSStJskw5Hda7zbCAgAA4NCotdbWe4Yhv5MkNUmOT+V32zxvpKTGMmgAAAAOvp6S2uZ54/hUfncvgMuXH33kqVqHr4x16L13y6ABAAA42PXbexvr0GsdvvLlRx95KkmpH/vYx4YkGZJf7TtHIQEAAMDBj+CkDMmvJsnHPvaxoWRnCtz+tfe85x3jODxRer+h994jhgEAADig7VtKKb2UtWma3/PkE088laTWJO3zn/98ffKJJ54aSv5FrbX3ntn1AgAA4EDWb89ca+1Dyb948oknnvr85z9fk7QhSaZpGv7wD/+wveO226e55Of63FOKCTAAAAAHsYCTDLWOvfydvzhz5om95t0fueU9d9yxMgz194eS985z69ndJRoAAAAOiDYMtcw9j81z+7EnTp/e3k3i7wjc+sTp01tjqX+vp5TWmuOQAAAAOFj121rvKWUs9e89cfr01v7u3R/ALUk5cebMF1pv31gsFnX3ewAAAHAg+nexWNTW2zdOnDnzhexs7txeKoD7ffffX7/8zDMbpZfPlhJTYAAAAA5O/bbWS0kpvXz2y888s3Hf/ffX7C5/Tl581FFJkrvuuuv46rlzXxmG+r5pmlsp7gUGAADg2tV72jgOdZ7bo6duueUjDz300OW9H71cACfJkGR+3x13/LU6Dv/bNC3nUurgcgIAAHDtBnCbx3ExtGn+Nx89ffq39tp2/++81GR3vu/++4dHT5/+rd7zhcViZei9OxcYAACAazR++7zTrvnCo6dP/9Z999//ovhN8rJn/dYk/YMf/OD3t2n5cE9u7L07FgkAAIBrTSullJJcrOPigw8//PCf5AWbX+0P3Zd8giT14Ycf/uPUfv8wDKX11rNv7TQAAAC8xXrrrQ/DUFL7/Q8//PAf73buS55o9EoT3XbfffcPjzxy+vN9nv/RymIx9B5LoQEAALg26rdnXlkshj7P/+iRR05//r777h/yCsf5lu/yfCVJueuuu46dX33uoVqHD0/TNJdSbIoFAADAWxi/fR7HcWht/urNp95210MPPbSZnVXL/fUGcLI7Pr7zzjvfOw757dZyS++9xf3AAAAAvDVaKaXWmnPTnH/98ccffyyvsPR5f9x+1yf+9Kc/PTz++OOPza38bK318s79xe4HBgAA4KrrZad+L8+t/Ozjjz/+2Kc//enhu8Vv8uomwEmST37yk+Ov//qvT+9//wd+tqR9YZ7ntvt4k2AAAACuhpakD8NQe+rPPfLI1/+XvVZ9NQ8ur/HFxiTT+9//3v+olvo/TNO0V9giGAAAgDc7fjOOY229/cePPPLYP9hr1Ff7BMPreMHhzJln/5/vve17zpRafrr3vne+UvF5AAAA8CbFbx2GodTUX/j6I4/+g92efU0nFb2e3Zx7kuEvzjzze7e+/e1P1JqfTspi94VNggEAALiS5lLKUGvZbD2feuTRR//x64nfvIFgnT95zz3jY4899itzGf96rfXsUIeh9zb5bAAAALgSem/TUIeh1np2LuNff+yxx37lk/fcM76e+E3e4LLlTyfD30/mOz585wfG7fxyHYYf215Ocy2psSQaAACA19m+raetLMahzfPvTyv5+dNfffzrew36ep/0SkTqkGT+0Ic+fLJN2/99qfVvzvOc1uaplDr63AAAAHjV5dvbVOswDsOQ3to/rOPKf/K1r311Pa9z2fOVDuBk34HDH/zgB//91ub/rqTcOs92iQYAAOBVaUkyDGPt6WdrHf7Thx9++B+/sDnfiOEKvdG+G9P1mWee+eo7Tp16sNf69lrrB2opZZ7nuZRyJYMbAACAQxK+rbU2DsNQay3p+WfDcvmphx977P/Kt4ep/Uq80JsRpM+Ppd//gQ/8VOntvyml/Ehrc1rr814o+4wBAACOdvgm6bWWodYhvff/t5f6nz/y9a//5gvb8kp5syaye4Hb3vOeO6677rqVn+9t+emk3tl738n71nqt1WZZAAAAR0dvrbVaa6m11p2Vwu3xUhd/f2tr+5efeOL01v6evNIv/mbH5/PF/s53vev47W+74eemXu8ryYeTZJ572tzn1KTEztEAAACHMXp70tKSOpRhGHayrydfHUv73DPPrX3hz//szy6/sCHfDFcjOMs999wzPPjgg7tnBH98/NCH/uzuzP3fWvb5p4ZSb9yJ4TnZXfv9gsmwKAYAADggsbv35762q8Ows/3U3NvFRRl+M0P51a997V1fTP75lCT33HPP+OCDD865Qvf6vpUB/Pxr3Xvv3cMDD3xx2vvGnXfe+c5hHD9Zer93nqe/Wkq5fhiG9N73gvj5KE6SWmt5wXsWxwAAAG9N5O6Fbt/ttZrd5cvDMKSUknme03u/NAzjl3spD8zT9OuPP/74n+89+N577x4feOCLb3r4vpUBWT7zmc/Uz372sz371nR/5M4733l5sfjxWtpfnaf+0dbmO5OcGIaaUmqSntZ33vBuDwMAAPAWqbWmJ6m7B/703jLPLUk2ah0eH8bypdbrl48vl7/zlX3Rm6R+5jOfKZ/97Gfb1QrftzKAv+P177333uGBBx6YXngtP3Lnnd+7MY4/WEv5wdLaDyT9B1vyvWnt+l769a31k6WUk71nUcyBAQAA3lS9J6Vk2Xtfr7Wsl14updZLNXk6Kd/qtf5/rfdvnZimb33l8cefzgs2sbr33nvHBx544KpNe6/FAP6O93LffffVP/mTPym/9mu/Nr3S7330ox8d//RP/3S46aabx83Ny9VKaAAAgDc9gXPs2PF24cL56fu+7/vmL33pS9MrxezP/MzPjN///d/fP/e5z131Se9BCOCXel/17rvvLknyxS9+seVN2AYbAACAN6Tefffddbfb9t/q2q+1N3rQRqdGvQAAANeW7hIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADwlvv/AXGH8+WD2Ai3AAAAAElFTkSuQmCC";
function rand(min, max){
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function stepf() {
            var x = getPlayerX();
            var z = getPlayerZ();
            var blockX = Math.round(x - 0.5);
            var blockZ = Math.round(z - 0.5);
            while (x < 1) x += 1;
            while (z < 1) z += 1;
            while (x > 1) x -= 1;
            while (z > 1) z -= 1;
 
            if (Math.round(x * 100) == 31) x -= 0.01;
            if (Math.round(z * 100) == 31) z -= 0.01;
            if (Math.round(x * 100) == 69) x += 0.01;
            if (Math.round(z * 100) == 69) z += 0.01;
            if (Math.round(x * 100) == 30) blockX--;
            if (Math.round(z * 100) == 30) blockZ--;
            if (Math.round(x * 100) == 70) blockX++;
            if (Math.round(z * 100) == 70) blockZ++;
            if (getTile(blockX, getPlayerY(), blockZ) == 0 && getTile(blockX, getPlayerY() - 1, blockZ) == 0) return false;
 
            if (Block.getDestroyTime(getTile(blockX, getPlayerY() - 1, blockZ)) <= 0.1 && Block.getDestroyTime(getTile(blockX, getPlayerY(), blockZ)) <= 0.1) return false;
 
            if (Math.round(x * 100) == 30 || Math.round(x * 100) == 70) return true;
            if (Math.round(z * 100) == 30 || Math.round(z * 100) == 70) return true;
            return false;
        }

var random1 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'z', 'x', 'c', 'v', 'b', 'n', 'm'];

var button2iv = false;
var button3iv = false;
var button4iv = false;
var button5iv = false;
var button6iv = false;


function dip2px(dips){
    var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    return Math.ceil(dips * ctx.getResources().getDisplayMetrics().density);
    }
    var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
    try{
             var layout = new android.widget.LinearLayout(ctx);
             layout.setOrientation(1);
if(transparent==false)   
{
var menuBtn = new android.widget.ImageView(ctx);
menuBtn.setImageBitmap(android.graphics.BitmapFactory.decodeByteArray(android.util.Base64.decode(icon, 0), 0, android.util.Base64.decode(icon, 0).length));    
}else{
if(transparent==true)
{
var menuBtn = new android.widget.ImageView(ctx);
menuBtn.setImageBitmap(android.graphics.BitmapFactory.decodeByteArray(android.util.Base64.decode(icon, 0), 0, android.util.Base64.decode(icon, 0).length));    
}
}


			
    menuBtn.setOnClickListener(new android.view.View.OnClickListener({
    onClick: function(viewarg){
    mainMenu();
    exit();
    GUI.dismiss();
    }
    }));
    layout.addView(menuBtn);
    



GUI = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
    
GUI.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


        
			 GUI.showAtLocation(ctx.getWindow().getDecorView(), Gravity.RIGHT | Gravity.TOP, losat, tasol);    
    }catch(err){
    print('An error occured: ' + err);
    }
    }}));

function mainMenu(){
    var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
    try{
    var menuLayout = new android.widget.LinearLayout(ctx);
    var menuScroll = new android.widget.ScrollView(ctx);
    var menuLayout1 = new android.widget.LinearLayout(ctx);
    menuLayout.setOrientation(1);
    menuLayout1.setOrientation(1);
    menuScroll.addView(menuLayout);
    menuLayout1.addView(menuScroll);
    
    var name = new android.widget.TextView(ctx);
            name.setTextSize(20);
            name.setText(cname + " " + cversion);
           name.setTextColor(RED); 
name.setGravity(android.view.Gravity.CENTER);
           menuLayout.addView(name);
           

           
    var text = new      android.widget.TextView(ctx);
text.setTextSize(16);
if(lang=="eng"){
text.setText("\nCreator: Kevin Basconi");
}else{
text.setText("\nСоздатель: Kevin Basconi");
}
text.setGravity(android.view.Gravity.CENTER);
text.setTextColor(GREEN);
menuLayout.addView(text);

      var button1 = new android.widget.Button(ctx); 
if(lang=="eng"){      
      button1.setText('Settings');
      }else{
      button1.setText('Настройки');
      }
     button1.setTextColor(BLUE); 
      button1.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
      settings();
      exitUI.dismiss();
      menu.dismiss(); 
      }
      }));
      menuLayout.addView(button1);
      

      var button2ivx = new android.widget.Button(ctx);
if(lang=="eng"){      
      button2ivx.setText('Hide button of cheat');
      }else{
      button2ivx.setText('Скрыть кнопку чита');
      }
     button2ivx.setTextColor(RED); 
      button2ivx.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){
GUI.dismiss();
menu.dismiss();
exitUI.dismiss();
      }
      }));
      
var group = new android.widget.Button(ctx);

if(lang=="eng"){   
               group.setText("Official Group (VK)");
               }else{
group.setText("Официальная группа (ВК)");               	
               }
			   group.setTextColor(BLUE);
               group.setOnClickListener(new android.view.View.OnClickListener({
                   onClick: function(viewarg){
               ctx.runOnUiThread(new java.lang.Runnable({run: function(){
            var webs = new android.webkit.WebView(ctx);
            var webset = webs.getSettings();
            webset.setJavaScriptEnabled(true);
            webs.setWebChromeClient(new android.webkit.WebChromeClient());
            webs.setWebViewClient(new android.webkit.WebViewClient());
            webs.loadUrl("http://vk.com/club103866091");
            new android.app.AlertDialog.Builder(ctx).setView(webs).show();
if(lang=="eng"){                
clientMessage('§2Link: §6http://vk.com/cheat_kiellt')
}else{
clientMessage('§2Ссылка: §6http://vk.com/cheat_kiellt')	
}
			}}));
                   }
               }));
               menuLayout.addView(group);      
      menuLayout.addView(button2ivx);             
      

      
var checked3gf = new android.widget.CheckBox(ctx);
if(lang=="eng"){
                checked3gf.setText('Fly');
                }else{
checked3gf.setText('Полёт');                	
                }
checked3gf.setTextColor(android.graphics.Color.parseColor(color1)); 
                checked3gf.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!gfa3)
{
gfa3 = true;        
flyw = true;
flyg = true;
fly1s()
fly2s()
fly3s()
}
else
{                         
gfa3 = false;          
flyw = false;
flyg = false;
fly1.dismiss()
fly2.dismiss()
fly3.dismiss()
};
checked3gf.setChecked(gfa3);
                    }
                }));                menuLayout.addView(checked3gf);
                
      var checked2 = new android.widget.CheckBox(ctx);
if(lang=="eng"){
                checked2.setText('Fake Gamemode 1/0');
                }else{
checked2.setText('Фейковый Gamemode 1/0');                	
                }
                
checked2.setTextColor(android.graphics.Color.parseColor(color1));                
                checked2.setChecked(osnova2);
                checked2.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas2)
{
osnovas2 = true;                         
osnova2 = true;
if(Launcher.ismcpe() || ticklaj==1)
{
if(lang=="eng")
{
clientMessage("§7(Kiellt) §cThis function is not working on MCPEMaster!");	
}else{
clientMessage("§7(Kiellt) §cЭта функция не работает в MCPEMaster'e на серверах.");	
}
}
Level.setGameMode(1);
}
else
{                         
osnovas2 =false;             
osnova2 = false; 
Level.setGameMode(0);
};
checked2.setChecked(osnova2);
                    }
                }));                menuLayout.addView(checked2);
                
      var checked3 = new android.widget.CheckBox(ctx);
if(lang=="eng"){
                checked3.setText('JetPack');
                }else{
checked3.setText('Джет-пак');                	
                }
checked3.setTextColor(android.graphics.Color.parseColor(color1));                
                checked3.setChecked(osnova3);
                checked3.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas3)
{
osnovas3 = true;                         
osnova3 = true;
jtp = true;
}
else
{                         
osnovas3 =false;             
osnova3 = false; 
jtp = false;
};
checked3.setChecked(osnova3);
                    }
                }));                menuLayout.addView(checked3);
                
      var checked4 = new android.widget.CheckBox(ctx);

if(lang=="eng")     
{ 
checked4.setText('AimBot');
}else{
checked4.setText('Авто-наводка на игрока');
}
checked4.setTextColor(android.graphics.Color.parseColor(color1));                
                checked4.setChecked(osnova4);
                checked4.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas4)
{
osnovas4 = true;                         
osnova4 = true;
killaura = true;
}
else
{                         
osnovas4 =false;             
osnova4 = false; 
killaura = false;
};
checked4.setChecked(osnova4);
                    }
                }));                menuLayout.addView(checked4);   
                
      var checked5 = new android.widget.CheckBox(ctx);  
if(lang=="eng"){
                checked5.setText('Eternal day');
                }else{
checked5.setText('Вечный день');                	
                }
checked5.setTextColor(android.graphics.Color.parseColor(color1));                
                checked5.setChecked(osnova5);
                checked5.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas5)
{
osnovas5 = true;                         
osnova5 = true;
eday = true;
}
else
{                         
osnovas5 =false;             
osnova5 = false; 
eday = false;
};
checked5.setChecked(osnova5);
                    }
                }));                menuLayout.addView(checked5);  
                
      var checked6 = new android.widget.CheckBox(ctx);
if(lang=="eng"){ 
                checked6.setText('No walls');
                }else{
checked6.setText('Проход сквозь стены');                	
                }
checked6.setTextColor(android.graphics.Color.parseColor(color1));                
                checked6.setChecked(osnova6);
                checked6.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas6)
{
osnovas6 = true;                         
osnova6 = true;
nwls = true;
Entity.setCollisionSize(getPlayerEnt(), 0.1, 0.1);
}
else
{                         
osnovas6 =false;             
osnova6 = false; 
nwls = false;
Entity.setCollisionSize(getPlayerEnt(), 1, 2);
};
checked6.setChecked(osnova6);
                    }
                }));                menuLayout.addView(checked6);
                
      var checked7 = new android.widget.CheckBox(ctx);
if(lang=="eng"){ 
                checked7.setText('Tap teleporter');
                }else{
checked7.setText('Телепортация тапом');                	
                }
checked7.setTextColor(android.graphics.Color.parseColor(color1));                
                checked7.setChecked(osnova7);
                checked7.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas7)
{
if(Launcher.ismcpe() || ticklaj==1)
{
if(lang=="eng")
{
clientMessage("§7(Kiellt) §cThis function is not working on MCPEMaster!");	
}else{
clientMessage("§7(Kiellt) §cЭта функция не работает в MCPEMaster'e на серверах.");	
}
}
osnovas7 = true;                         
osnova7 = true;
ttp = true;
}
else
{                         
osnovas7 =false;             
osnova7 = false; 
ttp = false;
};
checked7.setChecked(osnova7);
                    }
                }));                menuLayout.addView(checked7); 
                
      var checked8 = new android.widget.CheckBox(ctx);
if(lang=="eng"){  
                checked8.setText('WaterWalk');
                }else{
checked8.setText('Хождение по воде');                	
                }
checked8.setTextColor(android.graphics.Color.parseColor(color1));                
                checked8.setChecked(osnova8);
                checked8.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas8)
{
osnovas8 = true;                         
osnova8 = true;
wtw = true;
}
else
{                         
osnovas8 =false;             
osnova8 = false; 
wtw = false;
};
checked8.setChecked(osnova8);
                    }
                }));                menuLayout.addView(checked8);
                
      var checked9 = new android.widget.CheckBox(ctx);
if(lang=="eng"){  
                checked9.setText('AutoSethome');
                }else{
checked9.setText('Авто-Сетхом');                	
                }
checked9.setTextColor(android.graphics.Color.parseColor(color1));                
                checked9.setChecked(osnova9);
                checked9.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas9)
{
if(Launcher.ismcpe() || ticklaj==1)
{
if(lang=="eng")
{
clientMessage("§7(Kiellt) §cThis function is not working on MCPEMaster!");	
}else{
clientMessage("§7(Kiellt) §cЭта функция не работает в MCPEMaster'e на серверах.");	
}
}
osnovas9 = true;                         
osnova9 = true;
aus = true;
}
else
{                         
osnovas9 =false;             
osnova9 = false; 
aus = false;
};
checked9.setChecked(osnova9);
                    }
                }));                menuLayout.addView(checked9); 
                
      var checked10 = new android.widget.CheckBox(ctx);
if(lang=="eng"){  
                checked10.setText('SpeedHack');
                }else{
checked10.setText('Быстрая ходьба');                	
                }
checked10.setTextColor(android.graphics.Color.parseColor(color1));                
                checked10.setChecked(osnova10);
                checked10.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas10)
{
osnovas10 = true;                         
osnova10 = true;
sdh = true;
}
else
{                         
osnovas10 =false;             
osnova10 = false; 
sdh = false;
};
checked10.setChecked(osnova10);
                    }
                }));                menuLayout.addView(checked10); 
                
      var checked11 = new android.widget.CheckBox(ctx);
if(lang=="eng"){  
                checked11.setText('NoEffects');
                }else{
checked11.setText('Снять с себя все эффекты');                	
                }
checked11.setTextColor(android.graphics.Color.parseColor(color1));                
                checked11.setChecked(osnova11);
                checked11.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas11)
{
osnovas11 = true;                         
osnova11 = true;
noeffects = true;
}
else
{                         
osnovas11 =false;             
osnova11 = false; 
noeffects = false;
};
checked11.setChecked(osnova11);
                    }
                }));                menuLayout.addView(checked11); 
                
      var checked12 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked12.setText('Visual road');
                }else{
checked12.setText('Визуальная дорога');                	
                }
checked12.setTextColor(android.graphics.Color.parseColor(color1));                
                checked12.setChecked(osnova12);
                checked12.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas12)
{
if(Launcher.ismcpe() || ticklaj==1)
{
if(lang=="eng")
{
clientMessage("§7(Kiellt) §cThis function is not working on MCPEMaster!");	
}else{
clientMessage("§7(Kiellt) §cЭта функция не работает в MCPEMaster'e на серверах.");	
}
}
osnovas12 = true;                         
osnova12 = true;
vsr = true;
}
else
{                         
osnovas12 =false;             
osnova12 = false; 
vsr = false;
}
checked12.setChecked(osnova12);
                    }
                }));                menuLayout.addView(checked12);  
                
      var checked13 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked13.setText('Glide');
                }else{
checked13.setText('Скольжение');                	
                }
checked13.setTextColor(android.graphics.Color.parseColor(color1));                
                checked13.setChecked(osnova13);
                checked13.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas13)
{
osnovas13 = true;                         
osnova13 = true;
glide = true;
}
else
{                         
osnovas13 =false;             
osnova13 = false; 
glide = false;
}
checked13.setChecked(osnova13);
                    }
                }));                menuLayout.addView(checked13); 
                
      var checked14 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked14.setText('Tower');
                }else{
checked14.setText('Прыгать тапом');                	
                }
checked14.setTextColor(android.graphics.Color.parseColor(color1));                
                checked14.setChecked(osnova14);
                checked14.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas14)
{
if(Launcher.ismcpe() || ticklaj==1)
{
if(lang=="eng")
{
clientMessage("§7(Kiellt) §cThis function is not working on MCPEMaster!");	
}else{
clientMessage("§7(Kiellt) §cЭта функция не работает в MCPEMaster'e на серверах.");	
}
}
osnovas14 = true;                         
osnova14 = true;
tower = true;
}
else
{                         
osnovas14 = false;             
osnova14 = false; 
tower = false;
};
checked14.setChecked(osnova14);
                    }
                }));                menuLayout.addView(checked14);  
                
      var checked15 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked15.setText('AutoSpawn');
                }else{
checked15.setText('Телепорт на спавн при маленьком HP');                	
                }
checked15.setTextColor(android.graphics.Color.parseColor(color1));                
                checked15.setChecked(osnova15);
                checked15.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas15)
{
if(Launcher.ismcpe() || ticklaj==1)
{
if(lang=="eng")
{
clientMessage("§7(Kiellt) §cThis function is not working on MCPEMaster!");	
}else{
clientMessage("§7(Kiellt) §cЭта функция не работает в MCPEMaster'e на серверах.");	
}
}
osnovas15 = true;                         
osnova15 = true;
autosp = true;
}
else
{                         
osnovas15 = false;             
osnova15 = false; 
autosp = false;
};
checked15.setChecked(osnova15);
                    }
                }));                menuLayout.addView(checked15);
                
      var checked16 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked16.setText('Step');
                }else{
checked16.setText('Лазать по стенам');                	
                }
checked16.setTextColor(android.graphics.Color.parseColor(color1));                
                checked16.setChecked(osnova16);
                checked16.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas16)
{
osnovas16 = true;                         
osnova16 = true;
step = true;
}
else
{                         
osnovas16 = false;             
osnova16 = false; 
step = false;
};
checked16.setChecked(osnova16);
                    }
                }));                menuLayout.addView(checked16);
                
      var checked17 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked17.setText('Tap TP-Player');
                }else{
checked17.setText('Телепорт к игрокам тапом');                	
                }
checked17.setTextColor(android.graphics.Color.parseColor(color1));                
                checked17.setChecked(osnova17);
                checked17.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas17)
{
osnovas17 = true;                         
osnova17 = true;
tppl = true;
}
else
{                         
osnovas17 = false;             
osnova17 = false; 
tppl = false;
};
checked17.setChecked(osnova17);
                    }
                }));                menuLayout.addView(checked17);
                
      var checked18 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked18.setText('AntiKnockBack');
                }else{
checked18.setText('Анти-отбрасывание');                	
                }
checked18.setTextColor(android.graphics.Color.parseColor(color1));                
                checked18.setChecked(osnova18);
                checked18.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas18)
{
osnovas18 = true;                         
osnova18 = true;
antiknockback = true;
}
else
{                         
osnovas18 = false;             
osnova18 = false; 
antiknockback = false;
};
checked18.setChecked(osnova18);
                    }
                }));                menuLayout.addView(checked18);  
                
      var checked19 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked19.setText('BowAimBot');
                }else{
checked19.setText('Авто-нацеливание на мобов и игроков луком');                	
                }
checked19.setTextColor(android.graphics.Color.parseColor(color1));                
                checked19.setChecked(osnova19);
                checked19.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas19)
{
osnovas19 = true;                         
osnova19 = true;
bowaim = true;
bowaimbot = true;
}
else
{                         
osnovas19 = false;             
osnova19 = false; 
bowaim = false;
bowaimbot = false;
};
checked19.setChecked(osnova19);
                    }
                }));                menuLayout.addView(checked19);
                
      var checked20 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked20.setText('FullBright');
                }else{
checked20.setText('Ночное видение');                	
                }
checked20.setTextColor(android.graphics.Color.parseColor(color1));                
                checked20.setChecked(osnova20);
                checked20.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas20)
{
osnovas20 = true;                         
osnova20 = true;
Entity.addEffect(Player.getEntity (), 16, 5000000, 999, true);  
}
else
{                         
osnovas20 = false;             
osnova20 = false; 
Entity.removeEffect(Player.getEntity (), 16);
};
checked20.setChecked(osnova20);
                    }
                }));                menuLayout.addView(checked20);     

      var checked21 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked21.setText('Drive');
                }else{
checked21.setText('Быстрое ломание блоков');                	
                }
checked21.setTextColor(android.graphics.Color.parseColor(color1));                
                checked21.setChecked(osnova21);
                checked21.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas21)
{
osnovas21 = true;                         
osnova21 = true;
Entity.addEffect(Player.getEntity (), 3, 5000000, 999, true);   
}
else
{                         
osnovas21 = false;             
osnova21 = false; 
Entity.removeEffect(Player.getEntity (), 3);
};
checked21.setChecked(osnova21);
                    }
                }));                menuLayout.addView(checked21); 
                
      var checked22 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked22.setText('AutoWalk');
                }else{
checked22.setText('Авто-ходьба');                	
                }
checked22.setTextColor(android.graphics.Color.parseColor(color1));                
                checked22.setChecked(osnova22);
                checked22.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas22)
{
osnovas22 = true;                         
osnova22 = true;
autowalk = true;  
}
else
{                         
osnovas22 = false;             
osnova22 = false; 
autowalk = false;
};
checked22.setChecked(osnova22);
                    }
                }));                menuLayout.addView(checked22);   
                
      var checked23 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked23.setText('Criticals');
                }else{
checked23.setText('Критические удары');                	
                }
checked23.setTextColor(android.graphics.Color.parseColor(color1));                
                checked23.setChecked(osnova23);
                checked23.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas23)
{
osnovas23 = true;                         
osnova23 = true;
criticals = true;
}
else
{                         
osnovas23 = false;             
osnova23 = false; 
criticals = false;
};
checked23.setChecked(osnova23);
                    }
                }));                menuLayout.addView(checked23); 
                
      var checked24 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked24.setText('BunnyHop');
                }else{
checked24.setText('Автоматические прыжки');                	
                }
checked24.setTextColor(android.graphics.Color.parseColor(color1));                
                checked24.setChecked(osnova24);
                checked24.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas24)
{
osnovas24 = true;                         
osnova24 = true;
bhop = true;
bhopd = true;
}
else
{                         
osnovas24 = false;             
osnova24 = false; 
bhop = false;
bhopd = false;
};
checked24.setChecked(osnova24);
                    }
                }));                menuLayout.addView(checked24);
                
      var checked25 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked25.setText('FastEat');
                }else{
checked25.setText('Быстрая еда');                	
                }
checked25.setTextColor(android.graphics.Color.parseColor(color1));                
                checked25.setChecked(osnova25);
                checked25.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas25)
{
osnovas25 = true;                         
osnova25 = true;
fastEatOn(256);
}
else
{                         
osnovas25 = false;             
osnova25 = false; 
fastEatOff(256);
};
checked25.setChecked(osnova25);
                    }
                }));                menuLayout.addView(checked25); 
                
      var checked26 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked26.setText('Spam in chat (quickly)');
                }else{
checked26.setText('Спам в чате (быстро)');                	
                }
checked26.setTextColor(android.graphics.Color.parseColor(color1));                
                checked26.setChecked(osnova26);
                checked26.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas26)
{
if(Launcher.ismcpe() || ticklaj==1)
{
if(lang=="eng")
{
clientMessage("§7(Kiellt) §cThis function is not working on MCPEMaster!");	
}else{
clientMessage("§7(Kiellt) §cЭта функция не работает в MCPEMaster'e на серверах.");	
}
}
osnovas26 = true;                         
osnova26 = true;
spam3on=true;
spamq3();
spamq3ss=true;
}
else
{                         
osnovas26 = false;             
osnova26 = false; 
spam3on=false;
spamq3ss=false;
};
checked26.setChecked(osnova26);
                    }
                }));                menuLayout.addView(checked26); 
                
      var checked27 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked27.setText('Spam in chat (slow)');
                }else{
checked27.setText('Спам в чате (медленно)');                	
                }
checked27.setTextColor(android.graphics.Color.parseColor(color1));                
                checked27.setChecked(osnova27);
                checked27.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas27)
{
if(Launcher.ismcpe() || ticklaj==1)
{
if(lang=="eng")
{
clientMessage("§7(Kiellt) §cThis function is not working on MCPEMaster!");	
}else{
clientMessage("§7(Kiellt) §cЭта функция не работает в MCPEMaster'e на серверах.");	
}
}
osnovas27 = true;                         
osnova27 = true;
spam4on=true;
spamq4();
spamq4ss=true;
}
else
{                         
osnovas27 = false;             
osnova27 = false; 
spam4on=false;
spamq4ss=false;
};
checked27.setChecked(osnova27);
                    }
                }));                menuLayout.addView(checked27); 
                
      var checked29 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked29.setText('Spam in chat 2 (slow)');
                }else{
checked29.setText('Спам в чате 2 (медленно)');                	
                }
checked29.setTextColor(android.graphics.Color.parseColor(color1));                
                checked29.setChecked(osnova29);
                checked29.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas29)
{
if(Launcher.ismcpe() || ticklaj==1)
{
if(lang=="eng")
{
clientMessage("§7(Kiellt) §cThis function is not working on MCPEMaster!");	
}else{
clientMessage("§7(Kiellt) §cЭта функция не работает в MCPEMaster'e на серверах.");	
}
}
osnovas29 = true;                         
osnova29 = true;
spam8on=true;
spamq8();
spamq8ss=true;
}
else
{         
osnovas29 = false;                         
osnova29 = false;                
spam8on=false;
spamq8();
spamq8ss=false;
spam8=0;
};
checked29.setChecked(osnova29);
                    }
                }));                menuLayout.addView(checked29);
                
                                  
                
      var checked28 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked28.setText('AutoLeave');
                }else{
checked28.setText('Авто-выход');                	
                }
checked28.setTextColor(android.graphics.Color.parseColor(color1));                
                checked28.setChecked(osnova28);
                checked28.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas28)
{
osnovas28 = true;                         
osnova28 = true;
autol = true;
}
else
{                         
osnovas28 = false;             
osnova28 = false; 
autol = false
};
checked28.setChecked(osnova28);
                    }
                }));                menuLayout.addView(checked28);   
                
      var checked30 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked30.setText('AutoEnchant');
                }else{
checked30.setText('Авто-зачар');                	
                }
checked30.setTextColor(android.graphics.Color.parseColor(color1));                
                checked30.setChecked(osnova30);
                checked30.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas30)
{
osnovas30 = true;                         
osnova30 = true;
autoenchant = true;
}
else
{                         
osnovas30 = false;             
osnova30 = false; 
autoenchant = false;
};
checked30.setChecked(osnova30);
                    }
                }));                menuLayout.addView(checked30);
                
      var checked31 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked31.setText('NoBlocks');
                }else{
checked31.setText('Избавление от блоков тапом');                	
                }
checked31.setTextColor(android.graphics.Color.parseColor(color1));                
                checked31.setChecked(osnova31);
                checked31.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas31)
{
if(Launcher.ismcpe() || ticklaj==1)
{
if(lang=="eng")
{
clientMessage("§7(Kiellt) §cThis function is not working on MCPEMaster!");	
}else{
clientMessage("§7(Kiellt) §cЭта функция не работает в MCPEMaster'e на серверах.");	
}
}
osnovas31 = true;                         
osnova31 = true;
noblocks = true;
}
else
{                         
osnovas31 = false;             
osnova31 = false; 
noblocks = false;
};
checked31.setChecked(osnova31);
                    }
                }));                menuLayout.addView(checked31);                

      var checked32 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked32.setText('Show life mobs');
                }else{
checked32.setText('Показать жизни мобов');                	
                }
checked32.setTextColor(android.graphics.Color.parseColor(color1));                
                checked32.setChecked(osnova32);
                checked32.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas32)
{
osnovas32 = true;                         
osnova32 = true;
seehealthmobs = true;
}
else
{                         
osnovas32 = false;             
osnova32 = false; 
seehealthmobs = false;
};
checked32.setChecked(osnova32);
                    }
                }));                menuLayout.addView(checked32);
                
                 
      var checked33 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked33.setText('AutoHack Password');
                }else{
checked33.setText('Авто-подбор паролей');                	
                }
checked33.setTextColor(android.graphics.Color.parseColor(color1));                
                checked33.setChecked(osnova33);
                checked33.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas33)
{
if(Launcher.ismcpe() || ticklaj==1)
{
if(lang=="eng")
{
clientMessage("§7(Kiellt) §cThis function is not working on MCPEMaster!");	
}else{
clientMessage("§7(Kiellt) §cЭта функция не работает в MCPEMaster'e на серверах.");	
}
}
osnovas33 = true;                         
osnova33 = true;
spam5on=true;
spamq5();
spamq5ss=true;
}
else
{                         
osnovas33 = false;             
osnova33 = false; 
spam5on=false;
spamq5ss=false;
spam5 = 0;
};
checked33.setChecked(osnova33);
                    }
                }));                menuLayout.addView(checked33);                

      var checked34 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked34.setText('FreeCam');
                }else{
checked34.setText('ФриКам');                	
                }
checked34.setTextColor(android.graphics.Color.parseColor(color1));                
                checked34.setChecked(osnova34);
                checked34.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas34)
{
if(Launcher.ismcpe() || ticklaj==1)
{
if(lang=="eng")
{
clientMessage("§7(Kiellt) §cThis function is not working on MCPEMaster!");	
}else{
clientMessage("§7(Kiellt) §cЭта функция не работает в MCPEMaster'e на серверах.");	
}
}	
osnovas34 = true;                         
osnova34 = true;
Level.setGameMode(3);
}
else
{                         
osnovas34 = false;             
osnova34 = false; 
Level.setGameMode(0);
};
checked34.setChecked(osnova34);
                    }
                }));                menuLayout.addView(checked34);  
                
      var checked35 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked35.setText('NoAntiPiar');
                }else{
checked35.setText('Обход анти-пиара');                	
                }
checked35.setTextColor(android.graphics.Color.parseColor(color1));                
                checked35.setChecked(osnova35);
                checked35.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas35)
{
osnovas35 = true;                         
osnova35 = true;
trr = true;
}
else
{                         
osnovas35 = false;             
osnova35 = false; 
trr = false;
};
checked35.setChecked(osnova35);
                    }
                }));                menuLayout.addView(checked35);  
                
      var checked36 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked36.setText('AutoHack Password through the base');
                }else{
checked36.setText('Авто-подбор паролей через базу');                	
                }
checked36.setTextColor(android.graphics.Color.parseColor(color1));                
                checked36.setChecked(osnova36);
                checked36.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas36)
{
if(Launcher.ismcpe() || ticklaj==1)
{
if(lang=="eng")
{
clientMessage("§7(Kiellt) §cThis function is not working on MCPEMaster!");	
}else{
clientMessage("§7(Kiellt) §cЭта функция не работает в MCPEMaster'e на серверах.");	
}
}
osnovas36 = true;                         
osnova36 = true;
hacktick = true;
}
else
{                         
osnovas36 = false;             
osnova36 = false; 
hacktick = false;
hacktime = 0;
};
checked36.setChecked(osnova36);
                    }
                }));                menuLayout.addView(checked36);  
                
      var checked37 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked37.setText('AntiBadHunger');
                }else{
checked37.setText('Анти-голод');                	
                }
checked37.setTextColor(android.graphics.Color.parseColor(color1));                
                checked37.setChecked(osnova37);
                checked37.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas37)
{
osnovas37 = true;                         
osnova37 = true;
antihanger = true;
}
else
{                         
osnovas37 = false;             
osnova37 = false; 
antihanger = false;
};
checked37.setChecked(osnova37);
                    }
                }));                menuLayout.addView(checked37);
                
      var checked38 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked38.setText('AntiBadHealth');
                }else{
checked38.setText('Бесконечная жизнь');                	
                }
checked38.setTextColor(android.graphics.Color.parseColor(color1));                
                checked38.setChecked(osnova38);
                checked38.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas38)
{
osnovas38 = true;                         
osnova38 = true;
antihealth = true;
}
else
{                         
osnovas38 = false;             
osnova38 = false; 
antihealth = false;
};
checked38.setChecked(osnova38);
                    }
                }));                menuLayout.addView(checked38); 
                
var checked39 = new android.widget.CheckBox(ctx);
if(lang=="eng"){   
                checked39.setText('TapSpam');
                }else{
checked39.setText('Тап-спам');                	
                }
checked39.setTextColor(android.graphics.Color.parseColor(color1));                
                checked39.setChecked(osnova39);
                checked39.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovas39)
{
if(Launcher.ismcpe() || ticklaj==1)
{
if(lang=="eng")
{
clientMessage("§7(Kiellt) §cThis function is not working on MCPEMaster!");	
}else{
clientMessage("§7(Kiellt) §cЭта функция не работает в MCPEMaster'e на серверах.");	
}
}
osnovas39 = true;                         
osnova39 = true;
tapspam = true;
}
else
{                         
osnovas39 = false;             
osnova39 = false; 
tapspam = false;
};
checked39.setChecked(osnova39);
                    }
                }));                menuLayout.addView(checked39);
        
                


			   var group1 = new android.widget.Button(ctx);
if(lang=="eng"){   
               group1.setText("Creator (VK)");
               }else{
group1.setText("Создатель (ВК)");               	
               }
group1.setTextColor(BLUE);
               group1.setOnClickListener(new android.view.View.OnClickListener({
                   onClick: function(viewarg){
               ctx.runOnUiThread(new java.lang.Runnable({run: function(){
            var webs = new android.webkit.WebView(ctx);
            var webset = webs.getSettings();
            webset.setJavaScriptEnabled(true);
            webs.setWebChromeClient(new android.webkit.WebChromeClient());
            webs.setWebViewClient(new android.webkit.WebViewClient());
            webs.loadUrl("http://vk.com/id354014516");
            new android.app.AlertDialog.Builder(ctx).setView(webs).show();
if(lang=="eng"){                 
clientMessage('§2Link: §6http://vk.com/kevin_basconi');     
}else{
clientMessage('§2Ссылка: §6http://vk.com/kevin_basconi'); 
}       
			}}));
                   }
               }));
               menuLayout.addView(group1);
               
               

               
    menu = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/2, ctx.getWindowManager().getDefaultDisplay().getHeight());
    menu.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(BLACK));    
menu.getBackground().setAlpha(300);  
menu.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(colorj));  
 
menu.showAtLocation(ctx.getWindow().getDecorView(),
kjss | android.view.Gravity.TOP, 0, 0);
    }catch(error){
    print('An error occured: ' + error);
    }
    }}));
    }
function exit(){
    var ctxe = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctxe.runOnUiThread(new java.lang.Runnable({ run: function(){
    try{
    var xLayout = new android.widget.LinearLayout(ctxe);
    var xButton = new android.widget.Button(ctxe);
    xButton.setText('X');
    xButton.setTextColor(BLUE);
    xButton.setOnClickListener(new android.view.View.OnClickListener({
    onClick: function(viewarg){
    exitUI.dismiss();
    menu.dismiss();
    GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 10, 195);
    }
    }));
    xLayout.addView(xButton);
    exitUI = new android.widget.PopupWindow(xLayout, dip2px(40), dip2px(40));
    
    
    exitUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
    exitUI.showAtLocation(ctxe.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 0, 700);
    }catch(exception){
    print(exception);
    }
    }}));
    } 
    

    
function settings(){
    var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
    try{
    var menuLayout = new android.widget.LinearLayout(ctx);
    var menuScroll = new android.widget.ScrollView(ctx);
    var menuLayout1 = new android.widget.LinearLayout(ctx);
    menuLayout.setOrientation(1);
    menuLayout1.setOrientation(1);
    menuScroll.addView(menuLayout);
    menuLayout1.addView(menuScroll);
    
    var name1 = new android.widget.TextView(ctx);
            name1.setTextSize(20);
if(lang=="eng"){   
            name1.setText("Settings\n");
            }else{
name1.setText("Настройки\n");            	
            }
           name1.setTextColor(RED); 
name1.setGravity(android.view.Gravity.CENTER);
           menuLayout.addView(name1);
           
      var button1xv = new android.widget.Button(ctx);
if(lang=="eng"){         
      button1xv.setText('Back');
      }else{
button1xv.setText('Назад');      	
      }
     button1xv.setTextColor(BLACK); 
      button1xv.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){    
      mainMenu();
      exit(); 
      menu1.dismiss();
      }
      }));
      menuLayout.addView(button1xv);           
    var name3 = new android.widget.TextView(ctx);
            name3.setTextSize(16);
if(lang=="eng"){    
            name3.setText("Change the language:");
            }else{
name3.setText("Изменить язык чита:");            	
            }
           name3.setTextColor(GREEN); 
name3.setGravity(android.view.Gravity.CENTER);
           menuLayout.addView(name3);                 
                
      var button1f = new android.widget.Button(ctx);
if(lang=="eng"){         
      button1f.setText('English');
      }else{
button1f.setText('Английский');      	
      }
     button1f.setTextColor(BLUE); 
      button1f.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){    
lang="eng";
GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 10, 195);
      menu1.dismiss();
      }
      }));
      menuLayout.addView(button1f); 
      
      var button2f = new android.widget.Button(ctx);
if(lang=="eng"){         
      button2f.setText('Russian');
      }else{
button2f.setText('Русский');      	
      }
     button2f.setTextColor(BLUE); 
      button2f.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){    
lang="rus";
      menu1.dismiss();
GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 10, 195);      
      }
      }));
      menuLayout.addView(button2f); 
      
    var name4 = new android.widget.TextView(ctx);
            name4.setTextSize(16);
if(lang=="eng"){    
            name4.setText("Change menu layout:");
            }else{
name4.setText("Изменить расположение меню:");            	
            }
           name4.setTextColor(GREEN); 
name4.setGravity(android.view.Gravity.CENTER);
           menuLayout.addView(name4); 
            
      var button3f = new android.widget.Button(ctx);
if(lang=="eng"){         
      button3f.setText('RIGHT');
      }else{
button3f.setText('Справа');      	
      }
     button3f.setTextColor(BLUE); 
      button3f.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){     
menu1.dismiss();
kjss = android.view.Gravity.RIGHT
GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 10, 195);
      }
      }));
      menuLayout.addView(button3f); 
      
      var button4f = new android.widget.Button(ctx);
if(lang=="eng"){         
      button4f.setText('Center');
      }else{
button4f.setText('Центр');      	
      }
     button4f.setTextColor(BLUE); 
      button4f.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){     
menu1.dismiss();
kjss = android.view.Gravity.CENTER
GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 10, 195);
      }
      }));
      menuLayout.addView(button4f);   
      
      var button5f = new android.widget.Button(ctx);
if(lang=="eng"){         
      button5f.setText('Left');
      }else{
button5f.setText('Слева');      	
      }
     button5f.setTextColor(BLUE); 
      button5f.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){     
menu1.dismiss();
kjss = android.view.Gravity.LEFT
GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 10, 195);
      }
      }));
      menuLayout.addView(button5f);                         
               
      
    var name4 = new android.widget.TextView(ctx);
            name4.setTextSize(16);
if(lang=="eng"){    
            name4.setText("Other:");
            }else{
name4.setText("Остальное:");            	
            }
           name4.setTextColor(GREEN); 
name4.setGravity(android.view.Gravity.CENTER);
           menuLayout.addView(name4);            
      
       var button3f = new android.widget.Button(ctx);
if(lang=="eng"){         
      button3f.setText('Text for spam');
      }else{
button3f.setText('Текст для спама');      	
      }
     button3f.setTextColor(BLUE); 
      button3f.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){    
textforspam();
      }
      }));
      menuLayout.addView(button3f);
      
       var button5f = new android.widget.Button(ctx);
if(lang=="eng"){         
      button5f.setText('Text for spam for .spamchat2');
      }else{
button5f.setText('Текст для спама в .spamchat2');      	
      }
     button5f.setTextColor(BLUE); 
      button5f.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){    
textspam2();
      }
      }));
      menuLayout.addView(button5f);        
      
       var button4f = new android.widget.Button(ctx);
if(lang=="eng"){         
      button4f.setText('Hack effects');
      }else{
button4f.setText('Взлом эффектов');      	
      }
     button4f.setTextColor(BLUE); 
      button4f.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){    
effects();
      }
      }));
      menuLayout.addView(button4f);
      
       var button6f = new android.widget.Button(ctx);
if(lang=="eng"){         
      button6f.setText('Change the color of the menu');
      }else{
button6f.setText('Изменить цвет меню');      	
      }
     button6f.setTextColor(BLUE); 
      button6f.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){    
changecolormenu()
      }
      }));
      menuLayout.addView(button6f);           
       var button7f = new android.widget.Button(ctx);
if(lang=="eng"){         
      button7f.setText('Leave game');
      }else{
button7f.setText('Выйти с игры');      	
      }
     button7f.setTextColor(BLUE); 
      button7f.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){    
ModPE.leaveGame()
      }
      }));
      menuLayout.addView(button7f);                                                        

var button8f = new android.widget.Button(ctx);
if(lang=="eng"){         
      button8f.setText('Troll Chat');
      }else{
button8f.setText('Тролл Чат');      	
      }
     button8f.setTextColor(BLUE); 
      button8f.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){    
trollchat()
      }
      }));
      menuLayout.addView(button8f); 
      
var button9f = new android.widget.Button(ctx);
if(lang=="eng"){         
      button9f.setText('Get coordinates');
      }else{
button9f.setText('Получить координаты');      	
      }
     button9f.setTextColor(BLUE); 
      button9f.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){    
clientMessage("§7(Kiellt) §6X:§2 " + parseInt(getPlayerX()) + " " + "§6Y:§2 " + parseInt(getPlayerY()) + " " + "§6Z: §2" + parseInt(getPlayerZ()));
      }
      }));
      menuLayout.addView(button9f); 
      
var button10f = new android.widget.Button(ctx);
if(lang=="eng"){         
      button10f.setText('Get object id');
      }else{
button10f.setText('Получить id предмета');      	
      }
     button10f.setTextColor(BLUE); 
      button10f.setOnClickListener(new android.view.View.OnClickListener({
      onClick: function(viewarg){    
if(lang=="eng")
{
clientMessage("§7(Kiellt) §6Object id: §2" + Player.getCarriedItem());
}else{
clientMessage("§7(Kiellt) §6ID предмета в руке: §2" + Player.getCarriedItem());
}
      }
      }));
      menuLayout.addView(button10f);       
                
      var checked2x = new android.widget.CheckBox(ctx);
if(lang=="eng"){    
                checked2x.setText('Show HP (For Mini-Games)');
                }else{
checked2x.setText('Показать кол-во хп (Для мини-игр)');                	
                }
checked2x.setTextColor(android.graphics.Color.parseColor(color1));                
                checked2x.setChecked(osnovax2);
                checked2x.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovasx2)
{
osnovasx2 = true;                         
osnovax2 = true;
showhp = true;
}
else
{                         
osnovasx2 = false;             
osnovax2 = false;
showhp = false; 
};
checked2x.setChecked(osnovax2);
                    }
                }));                menuLayout.addView(checked2x); 

      var checked5x = new android.widget.CheckBox(ctx);
if(lang=="eng"){    
                checked5x.setText('Get messages');
                }else{
checked5x.setText('Получать сообщения в чат');                	
                }
checked5x.setTextColor(android.graphics.Color.parseColor(color1));                
                checked5x.setChecked(osnovax5);
                checked5x.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovasx5)
{
osnovasx5 = true;                         
osnovax5 = true;
messagechatss = true;
messagechats = true;
}
else
{                         
osnovasx5 = false;             
osnovax5 = false;
messagechatss = false;
messagechats = false;
};
checked5x.setChecked(osnovax5);
                    }
                }));                menuLayout.addView(checked5x);  
                
var checked112x = new android.widget.CheckBox(ctx);
if(lang=="eng"){    
                checked112x.setText('Bypass protection MCPE MASTER');
                }else{
checked112x.setText('Обход защиты для серверов от MCPEMaster');                	
                }
checked112x.setTextColor(android.graphics.Color.parseColor(color1));                
                checked112x.setChecked(osnovax112);
                checked112x.setOnClickListener(new android.view.View.OnClickListener(
                {
                    onClick: function (viewarg)
{
if (!osnovasx112)
{
osnovasx112 = true;                         
osnovax112 = true;
ticklaj = 1;
mcped();
}
else
{                         
osnovasx112 = false;             
osnovax112 = false;
ticklaj = 0;
};
checked112x.setChecked(osnovax112);
                    }
                }));                menuLayout.addView(checked112x);                  
                

    menu1 = new android.widget.PopupWindow(menuLayout1, ctx.getWindowManager().getDefaultDisplay().getWidth()/2, ctx.getWindowManager().getDefaultDisplay().getHeight());
    menu1.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(BLACK));    
menu1.getBackground().setAlpha(300);  
menu1.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(colorj));    
    menu1.showAtLocation(ctx.getWindow().getDecorView(), kjss | android.view.Gravity.TOP, 0, 0);
    }catch(error){
    print('An error occured: ' + error);
    }
    }}));
    }  
    
function fly1s()
{
    var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
    try{
             var layout = new android.widget.LinearLayout(ctx);
             layout.setOrientation(1);
             var flys1 = new android.widget.Button(ctx);
             flys1.setText('UP');
             flys1.setTextColor(android.graphics.Color.BLUE);
    flys1.setOnClickListener(new android.view.View.OnClickListener({
    onClick: function(viewarg){
    	setPosition(getPlayerEnt(), Player.getX(), Player.getY()+1, Player.getZ());
    }
    }));
    layout.addView(flys1);
    
    fly1 = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
    fly1.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
    fly1.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, 0, 200);
    }catch(err){
    print('An error occured: ' + err);
    }
    }}));
    }
    
function fly2s()
{
    var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
    try{
             var layout = new android.widget.LinearLayout(ctx);
             layout.setOrientation(1);
             var flys2 = new android.widget.Button(ctx);
             flys2.setText('DOWN');
             flys2.setTextColor(android.graphics.Color.BLUE);
    flys2.setOnClickListener(new android.view.View.OnClickListener({
    onClick: function(viewarg){
    	setPosition(getPlayerEnt(), Player.getX(), Player.getY()-1, Player.getZ());
    }
    }));
    layout.addView(flys2);
    
    fly2 = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
    fly2.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
    fly2.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, 0, 280);
    }catch(err){
    print('An error occured: ' + err);
    }
    }}));
    }  
    
function fly3s()
{
    var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
    ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
    try{
             var layout = new android.widget.LinearLayout(ctx);
             layout.setOrientation(1);
             var flys3 = new android.widget.Button(ctx);
             flys3.setText('SPEED x1');
             flys3.setTextColor(android.graphics.Color.BLUE);
    flys3.setOnClickListener(new android.view.View.OnClickListener({
    onClick: function(viewarg){
     dasd++;
     if(dasd==0)
     {
     }
    	if(dasd==1)
    	{
    	flys3.setText('SPEED x2');
    	sdh = true;
    	}
    	if(dasd==2)
    	{
    	flys3.setText('SPEED x1');
    	dasd = 0;
    	sdh = false;
    	}
    }
    }));
    layout.addView(flys3);
    
    fly3 = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
    fly3.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
    fly3.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, 0, 120);
    }catch(err){
    print('An error occured: ' + err);
    }
    }}));
    }            
    
function fastEatOn(id) {
    Item.setProperties(4 + id, {
    "name": "apple",
    "id": 4,
    "icon": "apple",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 4,
      "saturation_modifier": "low",
      "is_meat": false
    }
  });
  Item.setProperties(66 + id, {
    "name": "golden_apple",
    "id": 66,
    "icon": "apple_golden",
    "category": "Miscellaneous",
    "stack_by_data": true,
    "use_animation": "eat",
    "use_duration": timeeat,
    "foil": false,
    "hover_text_color": "aqua",

    "food": {
      "nutrition": 4, 
      "saturation_modifier": "supernatural",
      "is_meat": false, 
      "effects": [
        {
          "name": "regeneration",
          "chance": 1.0,
          "duration": 5,
          "amplifier": 1
        },
        {
          "name": "absorption",
          "chance": 1.0,
          "duration": 120, 
          "amplifier": 0
        }
      ],
      "enchanted_effects": [
        {
          "name": "regeneration",
          "chance": 0.66,
          "duration": 30,
          "amplifier": 4
        },
        {
          "name": "absorption",
          "chance": 0.66,
          "duration": 120, 
          "amplifier": 0
        },
        {
          "name": "resistance", 
          "chance": 0.66,
          "duration": 300,
          "amplifier": 0
        },
        {
          "name": "fire_resistance",
          "chance": 0.66,
          "duration": 300,
          "amplifier": 0
        }
      ]
    }
  });
  Item.setProperties(210 + id, {
    "name": "appleEnchanted", 
    "id": 210,
    "icon": "apple_golden",
    "category": "Miscellaneous",
    "hand_equipped": false,
    "stack_by_data": true,
    "use_animation": "eat",
    "use_duration": timeeat,
    "foil": true,
    "hover_text_color": "light_purple",

    "food": {
      "nutrition": 4,
      "saturation_modifier": "supernatural",
      "is_meat": false,
      "effects": [
        {
          "name": "regeneration",
          "chance": 1.0,
          "duration": 30,
          "amplifier": 4
        },
        {
          "name": "absorption",
          "chance": 1.0,
          "duration": 120, 
          "amplifier": 0
        },
        {
          "name": "resistance", 
          "chance": 1.0,
          "duration": 300,
          "amplifier": 0
        },
        {
          "name": "fire_resistance",
          "chance": 1.0,
          "duration": 300,
          "amplifier": 0
        }
      ]
    }
  });
  Item.setProperties(26 + id, {
    "name": "mushroom_stew",
    "id": 26,
    "icon": "mushroom_stew",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": timeeat,
    "max_stack_size": 1,

    "food": {
      "nutrition": 6,
      "saturation_modifier": "normal",
      "is_meat": false,
      "using_converts_to": "item.bowl"
    }
  });
  Item.setProperties(41 + id, {
    "name": "bread",
    "id": 41,
    "icon": "bread",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 5,
      "saturation_modifier": "normal",
      "is_meat": false
    }
  });
  Item.setProperties(63 + id, {
    "name": "porkchop",
    "id": 63,
    "icon": "porkchop_raw",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 3,
      "saturation_modifier": "low",
      "is_meat": true
    }
  });
  Item.setProperties(64 + id, {
    "name": "porkchop_cooked",
    "id": 64,
    "icon": "porkchop_cooked",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 8,
      "saturation_modifier": "good",
      "is_meat": true
    }
  });
  Item.setProperties(93 + id, {
    "name": "fish",
    "id": 93,
    "icon": "fish",
    "use_animation": "eat",
    "use_duration": timeeat,
    "max_damage": 0,
    "stacked_by_data": true,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "poor",
      "is_meat": true
    }
  });
  Item.setProperties(204 + id, {
    "name": "salmon",
    "id": 204,
    "icon": "salmon",
    "use_animation": "eat",
    "use_duration": timeeat,
    "max_damage": 0,
    "stacked_by_data": true,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "poor",
      "is_meat": true
    }
  });
  Item.setProperties(205 + id, {
    "name": "clownfish",
    "id": 205,
    "icon": "clownfish",
    "use_animation": "eat",
    "use_duration": timeeat,
    "max_damage": 0,
    "stacked_by_data": true,

    "food": {
      "nutrition": 1,
      "saturation_modifier": "poor",
      "is_meat": true
    }
  });
  Item.setProperties(206 + id, {
    "name": "pufferfish",
    "id": 206,
    "icon": "pufferfish",
    "use_animation": "eat",
    "use_duration": timeeat,
    "max_damage": 0,
    "stacked_by_data": true,

    "food": {
      "nutrition": 1,
      "saturation_modifier": "poor",
      "is_meat": true,
      "effects": [
        {
          "name": "poison",
          "duration": 60,
          "amplifier": 3
        },
        {
          "name": "nausea", 
          "duration": 15,
          "amplifier": 1
        },
        {
          "name": "hunger",
          "duration": 15,
          "amplifier": 2
        }
      ]
    }
  });
  Item.setProperties(94 + id, {
    "name": "cooked_fish",
    "id": 94,
    "icon": "cooked_fish",
    "use_animation": "eat",
    "use_duration": timeeat,
    "max_damage": 0,
    "stacked_by_data": true,

    "food": {
      "nutrition": 5,
      "saturation_modifier": "normal",
      "eat_sound": "random.burp",
      "is_meat": true
    }
  });
  Item.setProperties(207 + id, {
    "name": "cooked_salmon",
    "id": 207,
    "icon": "cooked_salmon",
    "use_animation": "eat",
    "use_duration": timeeat,
    "max_damage": 0,
    "stacked_by_data": true,

    "food": {
      "nutrition": 6,
      "saturation_modifier": "good",
      "is_meat": true
    }
  });
  Item.setProperties(101 + id, {
    "name": "cookie",
    "id": 101,
    "icon": "cookie",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "poor",
      "is_meat": false
    }
  });
  Item.setProperties(104 + id, {
    "name": "melon",
    "id": 104,
    "icon": "melon",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "low",
      "is_meat": false
    }
  });
  Item.setProperties(107 + id, {
    "name": "beef",
    "id": 107,
    "icon": "beef_raw",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 3,
      "saturation_modifier": "low",
      "is_meat": true
    }
  });
  Item.setProperties(108 + id, {
    "name": "steak",
    "id": 108,
    "icon": "beef_cooked",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 8,
      "saturation_modifier": "good",
      "is_meat": true
    }
  });
  Item.setProperties(109 + id, {
    "name": "chicken",
    "id": 109,
    "icon": "chicken_raw",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "low",
      "is_meat": true,
      "effects": [
        {
          "name": "hunger",
          "chance": 0.3,
          "duration": 30,
          "amplifier": 0
        }
      ]
    }
  });
  Item.setProperties(110 + id, {
    "name": "cooked_chicken",
    "id": 110,
    "icon": "chicken_cooked",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 6,
      "saturation_modifier": "normal",
      "is_meat": true
    }
  });
  Item.setProperties(167 + id, {
    "name": "muttonRaw",
    "id": 167,
    "icon": "mutton_raw",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "low",
      "is_meat": true
    }
  });
  Item.setProperties(168 + id, {
    "name": "muttonCooked",
    "id": 168,
    "icon": "mutton_cooked",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 6,
      "saturation_modifier": "good",
      "is_meat": true
    }
  });
  Item.setProperties(111 + id, {
    "name": "rotten_flesh",
    "id": 111,
    "icon": "rotten_flesh",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 4,
      "saturation_modifier": "poor",
      "is_meat": true,
      "effects": [
        {
          "name": "hunger",
          "chance": 0.3,
          "duration": 30,
          "amplifier": 0
        }
      ]
    }
  });
  Item.setProperties(119 + id, {
    "name": "spider_eye",
    "id": 119,
    "icon": "spider_eye",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "good",
      "is_meat": false,
      "effects": [
        {
          "name": "poison",
          "chance": 1.0,
          "duration": 5,
          "amplifier": 0
        }
      ]
    }
  });
  Item.setProperties(135 + id, {
    "name": "carrot",
    "id": 135,
    "icon": "carrot",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 3,
      "saturation_modifier": "normal",
      "is_meat": false
    },
    "seed": {
      "crop_result": "carrots",
      "plant_at": "farmland"
    }
  });
  Item.setProperties(136 + id, {
    "name": "potato",
    "id": 136,
    "icon": "potato",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 1,
      "saturation_modifier": "low",
      "is_meat": false
    },
    "seed": {
      "crop_result": "potatoes",
      "plant_at": "farmland"
    }
  });
  Item.setProperties(137 + id, {
    "name": "baked_potato",
    "id": 137,
    "icon": "potato_baked",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 5,
      "saturation_modifier": "normal",
      "is_meat": false
    }
  });
  Item.setProperties(138 + id, {
    "name": "poisonous_potato",
    "id": 138,
    "icon": "potato_poisonous",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "low",
      "is_meat": false,
      "effects": [
        {
          "name": "poison",
          "chance": 0.6,
          "duration": 5,
          "amplifier": 0
        }
      ]
    }
  });
  Item.setProperties(140 + id, {
    "name": "golden_carrot",
    "id": 140,
    "icon": "carrot_golden",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 6,
      "saturation_modifier": "supernatural",
      "is_meat": false
    }
  });
  Item.setProperties(144 + id, {
    "name": "pumpkin_pie",
    "id": 144,
    "icon": "pumpkin_pie",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 8,
      "saturation_modifier": "low",
      "is_meat": false
    }
  });
  Item.setProperties(155 + id, {
    "name": "rabbit",
    "id": 155,
    "icon": "rabbit",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 3,
      "saturation_modifier": "low",
      "is_meat": true
    }
  });
  Item.setProperties(156 + id, {
    "name": "cooked_rabbit",
    "id": 156,
    "icon": "rabbit_cooked",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 5,
      "saturation_modifier": "normal",
      "is_meat": true
    }
  });
  Item.setProperties(157 + id, {
    "name": "rabbit_stew",
    "id": 157,
    "icon": "rabbit_stew",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": timeeat,
    "max_stack_size": 1,

    "food": {
      "nutrition": 10,
      "saturation_modifier": "normal",
      "using_converts_to": "bowl",
      "is_meat": true
    }
  });
  Item.setProperties(201 + id, {
    "name": "beetroot",
    "id": 201,
    "icon": "beetroot",
    "use_animation": "eat",
    "use_duration": timeeat,

    "food": {
      "nutrition": 1,
      "saturation_modifier": "normal",
      "is_meat": false
    }
  });
    Item.setProperties(203 + id, {
    "name": "beetroot_soup",
    "id": 203,
    "icon": "beetroot_soup",
    "use_animation": "eat",
    "use_duration": timeeat,
    "max_stack_size": 1,

    "food": {
      "nutrition": 6,
      "saturation_modifier": "normal",
      "using_converts_to": "bowl",
      "is_meat": false
    }
  
  });
    
    

}


    
    function fastEatOff(id) {
    Item.setProperties(4 + id, {
    "name": "apple",
    "id": 4,
    "icon": "apple",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 4,
      "saturation_modifier": "low",
      "is_meat": false
    }
  });
  Item.setProperties(66 + id, {
    "name": "golden_apple",
    "id": 66,
    "icon": "apple_golden",
    "category": "Miscellaneous",
    "stack_by_data": true,
    "use_animation": "eat",
    "use_duration": 32,
    "foil": false,
    "hover_text_color": "aqua",

    "food": {
      "nutrition": 4, 
      "saturation_modifier": "supernatural",
      "is_meat": false, 
      "effects": [
        {
          "name": "regeneration",
          "chance": 1.0,
          "duration": 5,
          "amplifier": 1
        },
        {
          "name": "absorption",
          "chance": 1.0,
          "duration": 120, 
          "amplifier": 0
        }
      ],
      "enchanted_effects": [
        {
          "name": "regeneration",
          "chance": 0.66,
          "duration": 30,
          "amplifier": 4
        },
        {
          "name": "absorption",
          "chance": 0.66,
          "duration": 120, 
          "amplifier": 0
        },
        {
          "name": "resistance", 
          "chance": 0.66,
          "duration": 300,
          "amplifier": 0
        },
        {
          "name": "fire_resistance",
          "chance": 0.66,
          "duration": 300,
          "amplifier": 0
        }
      ]
    }
  });
  Item.setProperties(210 + id, {
    "name": "appleEnchanted", 
    "id": 210,
    "icon": "apple_golden",
    "category": "Miscellaneous",
    "hand_equipped": false,
    "stack_by_data": true,
    "use_animation": "eat",
    "use_duration": 32,
    "foil": true,
    "hover_text_color": "light_purple",

    "food": {
      "nutrition": 4,
      "saturation_modifier": "supernatural",
      "is_meat": false,
      "effects": [
        {
          "name": "regeneration",
          "chance": 1.0,
          "duration": 30,
          "amplifier": 4
        },
        {
          "name": "absorption",
          "chance": 1.0,
          "duration": 120, 
          "amplifier": 0
        },
        {
          "name": "resistance", 
          "chance": 1.0,
          "duration": 300,
          "amplifier": 0
        },
        {
          "name": "fire_resistance",
          "chance": 1.0,
          "duration": 300,
          "amplifier": 0
        }
      ]
    }
  });
  Item.setProperties(26 + id, {
    "name": "mushroom_stew",
    "id": 26,
    "icon": "mushroom_stew",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": 32,
    "max_stack_size": 1,

    "food": {
      "nutrition": 6,
      "saturation_modifier": "normal",
      "is_meat": false,
      "using_converts_to": "item.bowl"
    }
  });
  Item.setProperties(41 + id, {
    "name": "bread",
    "id": 41,
    "icon": "bread",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 5,
      "saturation_modifier": "normal",
      "is_meat": false
    }
  });
  Item.setProperties(63 + id, {
    "name": "porkchop",
    "id": 63,
    "icon": "porkchop_raw",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 3,
      "saturation_modifier": "low",
      "is_meat": true
    }
  });
  Item.setProperties(64 + id, {
    "name": "porkchop_cooked",
    "id": 64,
    "icon": "porkchop_cooked",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 8,
      "saturation_modifier": "good",
      "is_meat": true
    }
  });
  Item.setProperties(93 + id, {
    "name": "fish",
    "id": 93,
    "icon": "fish",
    "use_animation": "eat",
    "use_duration": 32,
    "max_damage": 0,
    "stacked_by_data": true,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "poor",
      "is_meat": true
    }
  });
  Item.setProperties(204 + id, {
    "name": "salmon",
    "id": 204,
    "icon": "salmon",
    "use_animation": "eat",
    "use_duration": 32,
    "max_damage": 0,
    "stacked_by_data": true,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "poor",
      "is_meat": true
    }
  });
  Item.setProperties(205 + id, {
    "name": "clownfish",
    "id": 205,
    "icon": "clownfish",
    "use_animation": "eat",
    "use_duration": 32,
    "max_damage": 0,
    "stacked_by_data": true,

    "food": {
      "nutrition": 1,
      "saturation_modifier": "poor",
      "is_meat": true
    }
  });
  Item.setProperties(206 + id, {
    "name": "pufferfish",
    "id": 206,
    "icon": "pufferfish",
    "use_animation": "eat",
    "use_duration": 32,
    "max_damage": 0,
    "stacked_by_data": true,

    "food": {
      "nutrition": 1,
      "saturation_modifier": "poor",
      "is_meat": true,
      "effects": [
        {
          "name": "poison",
          "duration": 60,
          "amplifier": 3
        },
        {
          "name": "nausea", 
          "duration": 15,
          "amplifier": 1
        },
        {
          "name": "hunger",
          "duration": 15,
          "amplifier": 2
        }
      ]
    }
  });
  Item.setProperties(94 + id, {
    "name": "cooked_fish",
    "id": 94,
    "icon": "cooked_fish",
    "use_animation": "eat",
    "use_duration": 32,
    "max_damage": 0,
    "stacked_by_data": true,

    "food": {
      "nutrition": 5,
      "saturation_modifier": "normal",
      "eat_sound": "random.burp",
      "is_meat": true
    }
  });
  Item.setProperties(207 + id, {
    "name": "cooked_salmon",
    "id": 207,
    "icon": "cooked_salmon",
    "use_animation": "eat",
    "use_duration": 32,
    "max_damage": 0,
    "stacked_by_data": true,

    "food": {
      "nutrition": 6,
      "saturation_modifier": "good",
      "is_meat": true
    }
  });
  Item.setProperties(101 + id, {
    "name": "cookie",
    "id": 101,
    "icon": "cookie",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "poor",
      "is_meat": false
    }
  });
  Item.setProperties(104 + id, {
    "name": "melon",
    "id": 104,
    "icon": "melon",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "low",
      "is_meat": false
    }
  });
  Item.setProperties(107 + id, {
    "name": "beef",
    "id": 107,
    "icon": "beef_raw",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 3,
      "saturation_modifier": "low",
      "is_meat": true
    }
  });
  Item.setProperties(108 + id, {
    "name": "steak",
    "id": 108,
    "icon": "beef_cooked",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 8,
      "saturation_modifier": "good",
      "is_meat": true
    }
  });
  Item.setProperties(109 + id, {
    "name": "chicken",
    "id": 109,
    "icon": "chicken_raw",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "low",
      "is_meat": true,
      "effects": [
        {
          "name": "hunger",
          "chance": 0.3,
          "duration": 30,
          "amplifier": 0
        }
      ]
    }
  });
  Item.setProperties(110 + id, {
    "name": "cooked_chicken",
    "id": 110,
    "icon": "chicken_cooked",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 6,
      "saturation_modifier": "normal",
      "is_meat": true
    }
  });
  Item.setProperties(167 + id, {
    "name": "muttonRaw",
    "id": 167,
    "icon": "mutton_raw",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "low",
      "is_meat": true
    }
  });
  Item.setProperties(168 + id, {
    "name": "muttonCooked",
    "id": 168,
    "icon": "mutton_cooked",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 6,
      "saturation_modifier": "good",
      "is_meat": true
    }
  });
  Item.setProperties(111 + id, {
    "name": "rotten_flesh",
    "id": 111,
    "icon": "rotten_flesh",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 4,
      "saturation_modifier": "poor",
      "is_meat": true,
      "effects": [
        {
          "name": "hunger",
          "chance": 0.3,
          "duration": 30,
          "amplifier": 0
        }
      ]
    }
  });
  Item.setProperties(119 + id, {
    "name": "spider_eye",
    "id": 119,
    "icon": "spider_eye",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "good",
      "is_meat": false,
      "effects": [
        {
          "name": "poison",
          "chance": 1.0,
          "duration": 5,
          "amplifier": 0
        }
      ]
    }
  });
  Item.setProperties(135 + id, {
    "name": "carrot",
    "id": 135,
    "icon": "carrot",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 3,
      "saturation_modifier": "normal",
      "is_meat": false
    },
    "seed": {
      "crop_result": "carrots",
      "plant_at": "farmland"
    }
  });
  Item.setProperties(136 + id, {
    "name": "potato",
    "id": 136,
    "icon": "potato",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 1,
      "saturation_modifier": "low",
      "is_meat": false
    },
    "seed": {
      "crop_result": "potatoes",
      "plant_at": "farmland"
    }
  });
  Item.setProperties(137 + id, {
    "name": "baked_potato",
    "id": 137,
    "icon": "potato_baked",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 5,
      "saturation_modifier": "normal",
      "is_meat": false
    }
  });
  Item.setProperties(138 + id, {
    "name": "poisonous_potato",
    "id": 138,
    "icon": "potato_poisonous",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 2,
      "saturation_modifier": "low",
      "is_meat": false,
      "effects": [
        {
          "name": "poison",
          "chance": 0.6,
          "duration": 5,
          "amplifier": 0
        }
      ]
    }
  });
  Item.setProperties(140 + id, {
    "name": "golden_carrot",
    "id": 140,
    "icon": "carrot_golden",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 6,
      "saturation_modifier": "supernatural",
      "is_meat": false
    }
  });
  Item.setProperties(144 + id, {
    "name": "pumpkin_pie",
    "id": 144,
    "icon": "pumpkin_pie",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 8,
      "saturation_modifier": "low",
      "is_meat": false
    }
  });
  Item.setProperties(155 + id, {
    "name": "rabbit",
    "id": 155,
    "icon": "rabbit",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 3,
      "saturation_modifier": "low",
      "is_meat": true
    }
  });
  Item.setProperties(156 + id, {
    "name": "cooked_rabbit",
    "id": 156,
    "icon": "rabbit_cooked",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 5,
      "saturation_modifier": "normal",
      "is_meat": true
    }
  });
  Item.setProperties(157 + id, {
    "name": "rabbit_stew",
    "id": 157,
    "icon": "rabbit_stew",
    "category": "Miscellaneous",
    "use_animation": "eat",
    "use_duration": 32,
    "max_stack_size": 1,

    "food": {
      "nutrition": 10,
      "saturation_modifier": "normal",
      "using_converts_to": "bowl",
      "is_meat": true
    }
  });
  Item.setProperties(201 + id, {
    "name": "beetroot",
    "id": 201,
    "icon": "beetroot",
    "use_animation": "eat",
    "use_duration": 32,

    "food": {
      "nutrition": 1,
      "saturation_modifier": "normal",
      "is_meat": false
    }
  });
    Item.setProperties(203 + id, {
    "name": "beetroot_soup",
    "id": 203,
    "icon": "beetroot_soup",
    "use_animation": "eat",
    "use_duration": 32,
    "max_stack_size": 1,

    "food": {
      "nutrition": 6,
      "saturation_modifier": "normal",
      "using_converts_to": "bowl",
      "is_meat": false
    }
  
  });
  
  
  }    


    
function chatHook(text){
var split = text.split(" ");	
if(trr==true){
			preventDefault();
			Server.sendChat(" "+replacetext(text));
	}else{
if(text==".help"){
preventDefault()
if(lang=="eng")
{
clientMessage('§7(Kiellt) §6.help '+'(1'+'/'+helpnumber+")"+':\n§6.spammsg <on/off> -§2 Fast sending messages.')
clientMessage('§6.spammsgs <on/off> -§2 Slow sending messages.') 
clientMessage('§6.spamchat <on/off> - §2Fast sending messages for chat.')
clientMessage('§6.spamchats <on/off> - §2Slow sending messages for chat.')
clientMessage('§6.auth <on/off> - §2Enable/disable the automatic sign-in, with spam.')
clientMessage('§6.spamsend <msg/tell/whisper/m/t/w> - §2Selecting the team to send spam.')
clientMessage('§6.apg <on/off> - §2Auto password guessing.')
clientMessage('§6.apgchange <l/log/login/without> - §2Change command for .apg.')
clientMessage('§6.enchant - §2Enchant an item for 1000 lvl.')
}else{
clientMessage('§7(Kiellt) §6.help '+'(1'+'/'+helpnumber+")"+':\n§6§l.spammsg on/off - §2Быстрая отправка сообщений игрокам.')
clientMessage('§6§l.spammsgs <on/off> - §2Медленная отправка сообщений игрокам.')
clientMessage('§6§l.spamchat <on/off> - §2Быстрая отправка спама в чат.')
clientMessage('§6§l.spamchats <on/off> - §2Медленная отправка спама в чат.')
clientMessage('§6§l.auth <on/off> - §2Включить/выключить автоматический вход в аккаунт, при спаме.')
clientMessage('§6§l.spamsend <msg/tell/whisper/m/t/w> - §2Выбор команды, для отправки спама.')
clientMessage('§6§l.apg <on/off> - §2Автоматический подбор паролей.')
clientMessage('§6§l.apgchange <l/log/login/without> - §2Изменить команду для подбора паролей в .apg.')
clientMessage('§6§l.enchant - §2Зачаровать предмет на 1000 лвл.')
}
}
if(text==".help 2"){
preventDefault()	
if(lang=="eng")
{
clientMessage('§7(Kiellt) §6.help '+'(2'+'/'+helpnumber+")"+':\n§6.spamsethome <on/off> - §2Spam the chat command /sethome.')
clientMessage('§6.spamsethomen <numeral> - §2Continue spam team .spamsethome.')	
clientMessage('§6.spamchatdelay <delay> - §2Delay for .spamchat.')	
clientMessage('§6.spammsgcommand <command> - §2Change command in .spammsg(s).')	
clientMessage('§6.op <on/off> - §2Get op on nicknames: 10000, etc.')	
clientMessage('§6.spamchat2 <on/off> - §2Spam in chat.')	
clientMessage('§6.ip - §2Get a server ip.')	
clientMessage('§6.ipsave - §2Save ip in file.')	
clientMessage('§6.list-save - §2keep a list of players in the file.')	
clientMessage('§6.guishow - §2Show gui of cheats.')	
clientMessage('§6.sendpackages - §2Sending packets in IP server.')
clientMessage('§6.changeloginbase <value> - §2Change of login in "AutoHack Password through the base".')	
}else{
clientMessage('§7(Kiellt) §6.help '+'(2'+'/'+helpnumber+")"+':\n§6§l.spamsethome <on/off> - §2Спам в чат командой /sethome.')
clientMessage('§6§l.spamsethomen <цифра> - §2Продолжить спам командой .spamsethome.')	
clientMessage('§6§l.spamchatdelay <задержка> - §2Задержка для .spamchat.')	
clientMessage('§6§l.spammsgcommand <команда> - §2Изменить команду в .spammsg(s).')	
clientMessage('§6§l.op <on/off> - §2Получить ор на ники: 10000 и т.д.')	
clientMessage('§6§l.spamchat2 <on/off> - §2Спам в чат.')	
clientMessage('§6§l.ip - §2Узнать IP-адрес сервера.')	
clientMessage('§6§l.ipsave - §2Сохранить ip сервера в файле.')	
clientMessage('§6§l.list-save - §2Сохранить список игроков в файле.')	
clientMessage('§6§l.guishow - §2Показать кнопку чита.')	
clientMessage('§6§l.sendpackages - §2Отправка пакетов на IP сервера.')	
clientMessage('§6§l.changeloginbase <значение> - §2Изменить login в "Авто-подборе паролей через базу".')	
}
}
if(text==".help 3")
{
preventDefault();
if(lang=="eng")
{
clientMessage('§7(Kiellt) §6.help '+'(3'+'/'+helpnumber+")"+':\n§6.spamchat2delay <delay> - §2Delay for .spamchat2.');
clientMessage("§6.getid - §2Get object id§2.");
clientMessage("§6.getxyz - §2Get coordinates§2.");
}else{
clientMessage('§7(Kiellt) §6.help '+'(3'+'/'+helpnumber+")"+':\n§6§l.spamchat2delay <задержка> - §2Задержка для .spamchat2.');
clientMessage("§6§l.getid - §2Получить id предмета.");
clientMessage("§6§l.getxyz - §2Получить координаты игрока.");
}
}
if(text==".spammsg"){
preventDefault()	
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.spammsg (on/off).')
}else{
clientMessage('§7(Kiellt) §4§lИспользование: §6.spammsg (on/off).')
}
}
if(text==".spammsg on"){
preventDefault()	
if(lang=="eng")
{
spam1on=true;
spamq1();
spamq1ss=true;
print('Spam successfully enabled.')
}else{
spam1on=true;
spamq1();
spamq1ss=true;
print('Спам успешно включён.')
}
}
if(text==".spammsg off"){
preventDefault()	
if(lang=="eng")
{
spam1on=false;
spamq1ss=false;
print('Spam successfully disabled.')
}else{
spam1on=false;
spamq1ss=false;
print('Спам успешно выключен.')
}
}
if(text==".spammsgs"){
preventDefault()	
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.spammsgs (on/off).')
}else{
clientMessage('§7(Kiellt) §4§lИспользование: §6.spammsgs (on/off).')
}
}
if(text==".spammsgs on"){
preventDefault()	
if(lang=="eng")
{
spam2on=true;
spamq2();
spamq2ss=true;
print('Spam successfully enabled.')
}else{
spam2on=true;
spamq2();
spamq2ss=true;
print('Спам успешно включён.')
}
}
if(text==".spammsgs off"){
preventDefault()	
if(lang=="eng")
{
spam2on=false;
spamq2ss=false;
print('Spam successfully disabled.')
}else{
spam2on=false;
spamq2ss=false;
print('Спам успешно выключен.')
}
}
if(text==".auth"){
preventDefault()	
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.auth (on/off).')
}else{
clientMessage('§7(Kiellt) §4§lИспользование: §6.auth (on/off).')	
}
}
if(text==".auth on"){
preventDefault()	
if(lang=="eng")
{
auth=true;
print('Automatic login with spam successfully enabled.')	
}else{
auth=true;
print('Автоматический вход при спаме успешно включен.')	
}
}
if(text==".auth off"){
preventDefault()	
if(lang=="eng")
{
auth=false;
print('Automatic login with spam successfully disabled.')
}else{
auth=false;
print('Автоматический вход при спаме успешно выключен.')	
}
}
if(text==".spamchat"){
preventDefault()	
if(lang=="eng")	
{
clientMessage('§7(Kiellt) §4Using: §6.spamchat (on/off).')	
}else{
clientMessage('§7(Kiellt) §4§lИспользование: §6.spamchat (on/off).')	
}
}
if(text==".spamchat on"){
preventDefault()	
if(lang=="eng")	
{
spam3on=true;
spamq3();
spamq3ss=true;
print('Spam successfully enabled.')
}else{
spam3on=true;
spamq3();
spamq3ss=true;
print('Спам успешно включён.')
}  
}
if(text==".spamchat off"){
preventDefault()	
if(lang=="eng")	
{
spam3on=false;
spamq3ss=false;
print('Spam successfully disabled.')
}else{
spam3on=false;
spamq3ss=false;
print('Спам успешно выключен.')
}
}
if(text==".spamchats"){
preventDefault()	
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.spamchats (on/off).')	
}else{
clientMessage('§7(Kiellt) §4§lИспользование: §6.spamchats (on/off).')		
}
}
if(text==".spamchats on")
{
preventDefault()
if(lang=="eng")
{
spam4on=true;
spamq4();
spamq4ss=true;
print('Spam successfully enabled.')
}else{
spam4on=true;
spamq4();
spamq4ss=true;
print('Спам успешно включён.')	
}
}
if(text==".spamchats off")
{
preventDefault()
if(lang=="eng")
{
spam4on=false;
spamq4ss=false;
print('Spam successfully disabled.')
}else{
spam4on=false;
spamq4ss=false;
print('Спам успешно выключен.')	
}
}
if(text==".spamsend")
{
preventDefault()
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.spamsend (msg/tell/whisper/m/t/w).')	
}else{
clientMessage('§7(Kiellt) §4§lИспользование: §6.spamsend (msg/tell/whisper/m/t/w).')		
}
}
if(text==".spamsend msg")
{
preventDefault()
if(lang=="eng")
{
print('saved!');
spamsend = "/msg";
}else{
print('Теперь спам будет отправляться в /msg!');
spamsend = "/msg";
}
}
if(text==".spamsend tell")
{
preventDefault()
if(lang=="eng")
{
print('saved!');
spamsend = "/tell";
}else{
print('Теперь спам будет отправляться в /tell!');
spamsend = "/tell";
}
}
if(text==".spamsend whisper")
{
preventDefault()
if(lang=="eng")
{
print('saved!');
spamsend = "/whisper";
}else{
print('Теперь спам будет отправляться в /whisper!');
spamsend = "/whisper";
}
}
if(text==".spamsend m")
{
preventDefault()
if(lang=="eng")
{
print('saved!');
spamsend = "/m";
}else{
print('Теперь спам будет отправляться в /m!');
spamsend = "/m";
}
}
if(text==".spamsend t")
{
preventDefault()
if(lang=="eng")
{
print('saved!');
spamsend = "/t";
}else{
print('Теперь спам будет отправляться в /t!');
spamsend = "/t";
}
}
if(text==".spamsend w")
{
preventDefault()	
if(lang=="eng")
{
print('saved!');
spamsend = "/w";
}else{
print('Теперь спам будет отправляться в /w!');
spamsend = "/w";
}
}
if(text==".apg")
{
preventDefault()	
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.apg (on/off).')		
}else{
clientMessage('§7(Kiellt) §4§lИспользование: §6.apg (on/off).')		
}
}
if(text==".apg on")
{
preventDefault()
if(lang=="eng")
{
spam5on=true;
spamq5();
spamq5ss=true;
print('Done.')
}else{
spam5on=true;
spamq5();
spamq5ss=true;
print('Готово.')	
}
}
if(text==".apg off")
{
preventDefault()	
if(lang=="eng")
{
spam5on=false;
spamq5ss=false;
print('Done.')
spam5 = 0;
}else{
spam5on=false;
spamq5ss=false;
print('Готово.')		
spam5 = 0;
}
}
if(text==".apgchange")
{
preventDefault()
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.apgchange (l/log/login/without).')	
}else{
clientMessage('§7(Kiellt) §4Использование: §6§l.apgchange (l/log/login/without).')	
}
}
if(text==".apgchange l")
{
preventDefault()	
if(lang=="eng")
{
passcom="/l ";
print('Done.');
}else{
passcom="/l ";
print('Готово.');
}
}
if(text==".apgchange log")
{
preventDefault()
if(lang=="eng")
{
passcom="/log ";
print('Done.');
}else{
passcom="/log ";
print('Готово.');
}
}
if(text==".apgchange login")
{
preventDefault()
if(lang=="eng")
{
passcom="/login ";
print('Done.');	
}else{
passcom="/login ";
print('Готово.');
}
}
if(text==".apgchange without")
{
preventDefault()	
if(lang=="eng")
{
passcom="";
print('Done.');	
}else{
passcom="";
print('Готово.');
}
}
if(text==".enchant")
{
preventDefault()	
if(lang=="eng")
{
print('Done.')
Player.enchant(Player.getSelectedSlotId(), Enchantment.EFFICIENCY,1000);
      Player.enchant(Player.getSelectedSlotId(), Enchantment.INFINITY,1000);
       Player.enchant(Player.getSelectedSlotId(), Enchantment.SMITE,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.DEPTH_STRIDER,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.FIRE_ASPECT,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.FORTUNE,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.FLAME,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.SHARPNESS,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.LOOTING,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.KNOCKBACK,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.UNBREAKING,1000);
}else{
print('Готово.')	
Player.enchant(Player.getSelectedSlotId(), Enchantment.EFFICIENCY,1000);
      Player.enchant(Player.getSelectedSlotId(), Enchantment.INFINITY,1000);
       Player.enchant(Player.getSelectedSlotId(), Enchantment.SMITE,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.DEPTH_STRIDER,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.FIRE_ASPECT,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.FORTUNE,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.FLAME,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.SHARPNESS,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.LOOTING,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.KNOCKBACK,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.UNBREAKING,1000);
}
}
if(text==".spamsethome")
{
preventDefault()
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.spamsethome (on/off).')	
}else{
clientMessage('§7(Kiellt) §4Использование: §6§l.spamsethome (on/off).')	
}
}
if(text==".spamsethome on")
{
preventDefault()
if(lang=="eng")
{
spam6on=true;
spamq6();
spamq6ss=true;
home = true;
print('Done.')
}else{
spam6on=true;
spamq6();
spamq6ss=true;
home = true;
print('Готово.')
}
}
if(text==".spamsethome off")
{
preventDefault()
if(lang=="eng")
{
spam6on=false;
spamq6();
spamq6ss=false;
homes = false;
home = 0;
print('Done.')
}else{
spam6on=false;
spamq6();
spamq6ss=false;
homes = false;
home = 0;
print('Готово.')
}
}
if(text==".spamsethomen")
{
preventDefault()
if(lang=="eng")
{
clientMessage("§7(Kiellt) §4Using: §6.spamsethomen <numeral>.");
}else{
clientMessage("§7(Kiellt) §4Использование: §6§l.spamsethomen <numeral>.");
}
}
if(split[0]==".spamsethomen")
{
preventDefault()
if(lang=="eng")
{
homes = split[1];
print('Done.')
}else{
homes = split[1];
print('Готово.')
}
}
if(text==".spamchatdelay")
{
preventDefault()
if(lang=="eng")
{
clientMessage("§7(Kiellt) §4Using: §6.spamchatdelay <delay>.");
}else{
clientMessage("§7(Kiellt) §4Использование: §6§l.spamchatdelay <задержка>.");
}
}
if(split[0]==".spamchatdelay")
{
preventDefault();
if(lang=="eng")
{
spam3zad = split[1];
print('Done.')
}else{
spam3zad = split[1];
print('Готово.')
}
}
if(text==".spammsgcommand")
{
preventDefault()
if(lang=="eng")
{
clientMessage("§7(Kiellt) §4Using: §6.spammsgcommand <command>.");
}else{
clientMessage("§7(Kiellt) §4Использование: §6§l.spammsgcommand <команда>.");
}
}
if(split[0]==".spammsgcommand")
{
preventDefault();
if(lang=="eng")
{
spamsend = split[1];
print('Done.')
}else{
spamsend = split[1];
print('Теперь спам будет отправляться в ' + spamsend);
}
}
if(text==".op")
{
preventDefault()
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.op (on/off).')	
}else{
clientMessage('§7(Kiellt) §4Использование: §6§l.op (on/off).')	
}
}
if(text==".op on")
{
preventDefault()
if(lang=="eng")
{
spam7on=true;
spamq7();
spamq7ss=true;
opnicks = true;
print('Done.')	
}else{
spam7on=true;
spamq7();
spamq7ss=true;
opnicks = true;
print('Готово.')
}
}
if(text==".op off")
{
preventDefault()
if(lang=="eng")
{
spam7on=false;
spamq7();
spamq7ss=false;
opnicks = false;
print('Done.')	
}else{
spam7on=false;
spamq7();
spamq7ss=false;
opnicks = false;
print('Готово.')
}
}
if(text==".blockidvr")
{
preventDefault()
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.blockidvr (block id).')	
}
else{
clientMessage('§7(Kiellt) §4Использование: §6§l.blockidvr (block id).')			
}
}
if(split[0]==".blockidvr")
{
preventDefault();
if(lang=="eng")
{
print('Done.')
blockid1 = split[1];
}else{
print('Готово.')
blockid1 = split[1];	
}
}
if(text==".spamchat2")
{
preventDefault()
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.spamchat2 (on/off).')	
}else{
clientMessage("§7(Kiellt) §4Использование: §6§l.spamchat2 (on/off).");
}
}
if(text==".spamchat2 on")
{
preventDefault()
if(lang=="eng")
{
spam8on=true;
spamq8();
spamq8ss=true;
print('Done.')		
}else{
spam8on=true;
spamq8();
spamq8ss=true;
print('Готово.')	
}
}
if(text==".spamchat2 off")
{
preventDefault()
if(lang=="eng")
{
spam8on=false;
spamq8();
spamq8ss=false;
spam8=0;
print('Done.')		
}else{
spam8on=false;
spamq8();
spamq8ss=false;
spam8=0;
print('Готово.')	
}
}
if(text==".spamchat2delay")
{
preventDefault()
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.spamchat2delay (delay).');
}else{
clientMessage("§7(Kiellt) §4Использование: §6§l.spamchat2 (delay).");
}
}
if(split[0]==".spamchat2delay")
{
preventDefault();
if(lang=="eng")
{
spam2chatzad = split[1]*20;
spam2chatzad2 = split[1]*40;
print('Done.')
}else{
spam2chatzad = split[1]*20;
spam2chatzad2 = split[1]*40;
print('Готово.')
}
}
if(text==".spamchat2delay")
{
preventDefault()
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.spamchat2delay (delay).');
}else{
clientMessage("§7(Kiellt) §4Использование: §6§l.spamchat2delay (задержка).");
}
}
if(text==".ip")
{
preventDefault()
if(lang=="eng")
{
clientMessage('§7(Kiellt) §6ip: §2' + Server.getAddress() + "§7:§5" + Server.getPort());
}else{
clientMessage('§7(Kiellt) §6ip: §2' + Server.getAddress() + "§7:§5" + Server.getPort());
}
}
if(text==".ipsave")
{
preventDefault()
if(lang=="eng")
{
clientMessage('§7(Kiellt) §6IP saved in: §2sdcard/games/com.mojang/ipsave.txt§6.');
file.create(files); 
if(file.read(files) == "")
{
file.write(files, "Server:" + Server.getAddress() + ":" + Server.getPort())
}else{
file.write(files, "\nServer:" + Server.getAddress() + ":" + Server.getPort())
}
}else{
clientMessage('§7(Kiellt) §6§lIP сервера успешно сохранено в: §2sdcard/games/com.mojang/ipsave.txt§6.');
file.create(files); 
if(file.read(files) == "")
{
file.write(files, "Server:" + Server.getAddress() + ":" + Server.getPort())
}else{
file.write(files, "\nServer:" + Server.getAddress() + ":" + Server.getPort())
}
}
}
if(text==".list-save")
{
preventDefault()
file.create(files1); 
var allplayers = Server.getAllPlayerNames();
file.write(files1, "List: " + "\n1)" + Server.getAllPlayerNames()[0] + "\n2)" + Server.getAllPlayerNames()[1] + "\n3)" + Server.getAllPlayerNames()[2] + "\n4)" + Server.getAllPlayerNames()[3] + "\n5)" + Server.getAllPlayerNames()[4] + "\n6)" + Server.getAllPlayerNames()[5] + "\n7)" + Server.getAllPlayerNames()[6] + "\n8)" + Server.getAllPlayerNames()[7] + "\n9)" + Server.getAllPlayerNames()[8] + "\n10)" + Server.getAllPlayerNames()[9] + "\n11)" + Server.getAllPlayerNames()[10] + "\n12)" + Server.getAllPlayerNames()[11] + "\n13)" + Server.getAllPlayerNames()[12] + "\n14)" + Server.getAllPlayerNames()[13] + "\n15)" + Server.getAllPlayerNames()[14] + "\n16)" + Server.getAllPlayerNames()[15] + "\n17" + Server.getAllPlayerNames()[16] + "\n18)" + Server.getAllPlayerNames()[17] + "\n19" + Server.getAllPlayerNames()[18] + "\n20)" + Server.getAllPlayerNames()[19] + "\n21)" + Server.getAllPlayerNames()[20] + "\n22)" + Server.getAllPlayerNames()[21] + "\n23)" + Server.getAllPlayerNames()[22] + "\n24)" + Server.getAllPlayerNames()[23] + "\n25)" + Server.getAllPlayerNames()[24] + "\n26)" + Server.getAllPlayerNames()[25] + "\n27)" + Server.getAllPlayerNames()[26] + "\n28)" + Server.getAllPlayerNames()[27] + "\n29)" + Server.getAllPlayerNames()[28] + "\n30)" + Server.getAllPlayerNames()[29] + "\n31)" + Server.getAllPlayerNames()[30] + "\n32)" + Server.getAllPlayerNames()[31] + "\n33)" + Server.getAllPlayerNames()[32] + "\n34)" + Server.getAllPlayerNames()[33] + "\n35)" + Server.getAllPlayerNames()[34] + "\n36)" + Server.getAllPlayerNames()[35] + "\n37)" + Server.getAllPlayerNames()[36] + "\n38)" + Server.getAllPlayerNames()[37] + "\n39)" + Server.getAllPlayerNames()[38] + "\n40)" + Server.getAllPlayerNames()[39] + "\n41)" + Server.getAllPlayerNames()[40] + "\n42)" + Server.getAllPlayerNames()[41] + "\n43)" + Server.getAllPlayerNames()[42] + "\n44)" + Server.getAllPlayerNames()[43] + "\n45)" + Server.getAllPlayerNames()[44] + "\n46)" + Server.getAllPlayerNames()[45] + "\n47)" + Server.getAllPlayerNames()[46] + "\n48)" + Server.getAllPlayerNames()[47] + "\n49)" + Server.getAllPlayerNames()[48] + "\n50)" + Server.getAllPlayerNames()[49])
if(lang=="eng"){
print('Done!')
clientMessage('§7(Kiellt) §6The file is saved in: §2' + sdcard + '/games/com.mojang/listsave.txt§6.')
}else{
print('Готово!')
clientMessage('§7(Kiellt) §6§lФайл сохранён в: §2' + sdcard + '/games/com.mojang/listsave.txt§6.')
}
}
}
if(text==".guishow")
{
preventDefault()
exit()
}
if(text==".sendpackages on")
{
preventDefault()
serverl = Server.getAddress() + ":" + Server.getPort();
ddooss = true;
if(lang=="eng"){
print("Started!");
}else{
print("Началась отправка пакетов на сервер!");
}
}
if(text==".sendpackages off")
{
preventDefault()
ddooss = false;
if(lang=="eng"){
print("Done.");
}else{
print("Готово.");
}
}
if(text==".sendpackages")
{
preventDefault()
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.sendpackages (on/off).');
}else{
clientMessage("§7(Kiellt) §4Использование: §6§l.sendpackages (on/off).");
}
}
if(text==".changeloginbase")
{
preventDefault()
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.changeloginbase (value).');
}else{
clientMessage("§7(Kiellt) §4Использование: §6§l.changeloginbase (значение).");
}
}
if(split[0]==".changeloginbase")
{
preventDefault()
if(lang=="eng")
{
print("Done!")
basemsg = split[1] + " ";
}else{
print("Готово!")
basemsg = split[1] + " ";
}
}
if(text==".getid")
{
preventDefault();
if(lang=="eng")
{
clientMessage("§7(Kiellt) §6Object id: §2" + Player.getCarriedItem());
}else{
clientMessage("§7(Kiellt) §6ID предмета в руке: §2" + Player.getCarriedItem());
}
}
if(text==".getxyz")
{
preventDefault();
if(lang=="eng")
{
clientMessage("§7(Kiellt) §6X:§2 " + parseInt(getPlayerX()) + " " + "§6Y:§2 " + parseInt(getPlayerY()) + " " + "§6Z: §2" + parseInt(getPlayerZ()));
}else{
clientMessage("§7(Kiellt) §6X:§2 " + parseInt(getPlayerX()) + " " + "§6Y:§2 " + parseInt(getPlayerY()) + " " + "§6Z: §2" + parseInt(getPlayerZ()));
}
}
if(text==".spgame")
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §4Using: §6.spgame (value).');
}else{
clientMessage("§7(Kiellt) §4Использование: §6§l.spgame (значение).");
}
}
if(split[0]==".spgame")
{
preventDefault()
if(lang=="eng")
{
print("Done!")
spgame = split[1];
}else{
print("Готово!")
spgame = split[1];
}
}
}


var files = file.select(sdcard + '/games/com.mojang','ipsave.txt');
var files1 = file.select(sdcard + '/games/com.mojang','listsave.txt');
var files2 = file.select(sdcard + '/games/com.mojang/minecraftpe','clientId.txt');
var files3 = file.select(sdcard + '/games/com.mojang/minecraftpe','options.txt');
var files4 = file.select(sdcard + '/games/com.mojang/minecraftpe','Kiellt.js');
var files5 = file.select(sdcard + '/games/com.mojang/minecraftpe','Function.js');

var posX=getPlayerX();
var posY=getPlayerY();
var posZ=getPlayerZ();
    
function attackHook(attacker, victim) 
{
if(seehealthmobs==true)
{
clientMessage('§7(Kiellt) §6HP: §2' + Entity.getHealth(victim) + '§4 ❤')
}
if(criticals==true)
{
setVelY(getPlayerEnt(), 0.2);	
}
if(tppl==true)
{
setPosition(getPlayerEnt(), Entity.getX(victim),Entity.getY(victim)+1,Entity.getZ(victim));
}
}    
    
function useItem(x, y, z, i, b, s) {
if(tapspam==true)
{
if(i==0)
{
Server.sendChat(spamtext);
}
}
if(ttp==true)
{
Entity.setPosition(Player.getEntity(), x, y + 3, z);
}	
if(tower==true)
{
setVelY(getPlayerEnt(), 0.4);
}
if(noblocks==true)
{
Level.destroyBlock(x, y, z, 0); 
}
}

function randomInteger(min, max) { 
var rand = min - 0.5 + Math.random() * (max - min + 1);
rand = Math.round(rand); 
return rand; 
}

var sgs = ["-","--","---","?","??","???","!","!!","!!!","+","++","+++",":","::",":::",";",";;",";;;"];

function spamq8()
{
if(spam8==spam2chatzad)
{
if(trr==true)
{
Server.sendChat(""+replacetext(sgs[randomInteger(0, 17)]+spam2chattext));
}else{
Server.sendChat(sgs[randomInteger(0, 17)]+spam2chattext);
}
}
if(spam8==spam2chatzad2)
{
if(trr==true){
Server.sendChat(""+replacetext(sgs[randomInteger(0, 17)]+spam2chattext2));
spam8=0;
}
}
}

function spamq7()
{
if(spam7==1)
{
Server.sendChat('/op ' + opnick)
spam7=0;
}
}

function spamq1()
{
if(spam1==1)
{
if(auth==true)	
{
Server.sendChat('/register 1234567890');
Server.sendChat('/login 1234567890');
}else{

}
}
if(spam1==1)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2q');
Server.sendChat(spamsend + " " + "q" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2q');
Server.sendChat(spamsend + " " + "q" + " " + spamtext)
}
}
if(spam1==2)
{
if(lang=="eng")
{	
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2w');
Server.sendChat(spamsend + " " + "w" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2w');
Server.sendChat(spamsend + " " + "w" + " " + spamtext)
}
}
if(spam1==3)
{
if(lang=="eng")
{		
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2e');
Server.sendChat(spamsend + " " + "e" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2e');
Server.sendChat(spamsend + " " + "e" + " " + spamtext)
}
}
if(spam1==4)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2r');
Server.sendChat(spamsend + " " + "r" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2r');
Server.sendChat(spamsend + " " + "r" + " " + spamtext)
}
}
if(spam1==5)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2t');
Server.sendChat(spamsend + " " + "t" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2t');
Server.sendChat(spamsend + " " + "t" + " " + spamtext)
}
}
if(spam1==6)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2y');
Server.sendChat(spamsend + " " + "y" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2y');
Server.sendChat(spamsend + " " + "y" + " " + spamtext)	
}
}
if(spam1==7)
{
if(lang=="eng")
{	
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2u');
Server.sendChat(spamsend + " " + "u" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2u');
Server.sendChat(spamsend + " " + "u" + " " + spamtext)
}
}
if(spam1==8)
{
if(lang=="eng")
{		
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2i');
Server.sendChat(spamsend + " " + "i" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2i');
Server.sendChat(spamsend + " " + "i" + " " + spamtext)
}
}
if(spam1==9)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2o');
Server.sendChat(spamsend + " " + "o" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2o');
Server.sendChat(spamsend + " " + "o" + " " + spamtext)	
}
}
if(spam1==10)
{
if(lang=="eng")
{				
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2p');
Server.sendChat(spamsend + " " + "p" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2p');
Server.sendChat(spamsend + " " + "p" + " " + spamtext)
}
}
if(spam1==11)
{
if(lang=="eng")
{				
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2a');
Server.sendChat(spamsend + " " + "a" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2a');
Server.sendChat(spamsend + " " + "a" + " " + spamtext)
}
}
if(spam1==12)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2s');
Server.sendChat(spamsend + " " + "s" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2s');
Server.sendChat(spamsend + " " + "s" + " " + spamtext)
}
}
if(spam1==13)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2d');
Server.sendChat(spamsend + " " + "d" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2d');
Server.sendChat(spamsend + " " + "d" + " " + spamtext)
}
}
if(spam1==14)
{
if(lang=="eng")
{				
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2f');
Server.sendChat(spamsend + " " + "f" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2f');
Server.sendChat(spamsend + " " + "f" + " " + spamtext)
}
}
if(spam1==15)
{
if(lang=="eng")
{				
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2g');
Server.sendChat(spamsend + " " + "g" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2g');
Server.sendChat(spamsend + " " + "g" + " " + spamtext)
}
}
if(spam1==16)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2h');
Server.sendChat(spamsend + " " + "h" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2h');
Server.sendChat(spamsend + " " + "h" + " " + spamtext)
}
}
if(spam1==17)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2j');
Server.sendChat(spamsend + " " + "j" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2j');
Server.sendChat(spamsend + " " + "j" + " " + spamtext)
}
}
if(spam1==18)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2k');
Server.sendChat(spamsend + " " + "k" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2k');
Server.sendChat(spamsend + " " + "k" + " " + spamtext)
}
}
if(spam1==19)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2l');
Server.sendChat(spamsend + " " + "l" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2l');
Server.sendChat(spamsend + " " + "l" + " " + spamtext)
}
}
if(spam1==20)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2z');
Server.sendChat(spamsend + " " + "z" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2z');
Server.sendChat(spamsend + " " + "z" + " " + spamtext)
}
}
if(spam1==21)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2x');
Server.sendChat(spamsend + " " + "x" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2x');
Server.sendChat(spamsend + " " + "x" + " " + spamtext)
}
}
if(spam1==22)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2c');
Server.sendChat(spamsend + " " + "c" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2c');
Server.sendChat(spamsend + " " + "c" + " " + spamtext)
}
}
if(spam1==23)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2v');
Server.sendChat(spamsend + " " + "v" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2v');
Server.sendChat(spamsend + " " + "v" + " " + spamtext)		
}
}
if(spam1==24)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2b');
Server.sendChat(spamsend + " " + "b" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2b');
Server.sendChat(spamsend + " " + "b" + " " + spamtext)
}
}
if(spam1==25)
{
if(lang=="eng")
{				
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2n');
Server.sendChat(spamsend + " " + "n" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2n');
Server.sendChat(spamsend + " " + "n" + " " + spamtext)
}
}
if(spam1==26)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2m');
Server.sendChat(spamsend + " " + "m" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2m');
Server.sendChat(spamsend + " " + "m" + " " + spamtext)
}
}
if(spam1==27)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §21');
Server.sendChat(spamsend + " " + "1" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §21');
Server.sendChat(spamsend + " " + "1" + " " + spamtext)
}
}
if(spam1==28)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §22');
Server.sendChat(spamsend + " " + "2" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §22');
Server.sendChat(spamsend + " " + "2" + " " + spamtext)
}
}
if(spam1==29)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §23');
Server.sendChat(spamsend + " " + "3" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §23');
Server.sendChat(spamsend + " " + "3" + " " + spamtext)
}
}
if(spam1==30)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §24');
Server.sendChat(spamsend + " " + "4" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §24');
Server.sendChat(spamsend + " " + "4" + " " + spamtext)
}
}
if(spam1==31)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §25');
Server.sendChat(spamsend + " " + "5" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §25');
Server.sendChat(spamsend + " " + "5" + " " + spamtext)
}
}
if(spam1==32)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §26');
Server.sendChat(spamsend + " " + "6" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §26');
Server.sendChat(spamsend + " " + "6" + " " + spamtext)
}
}
if(spam1==33)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §27');
Server.sendChat(spamsend + " " + "7" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §27');
Server.sendChat(spamsend + " " + "7" + " " + spamtext)
}
}
if(spam1==34)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §28');
Server.sendChat(spamsend + " " + "8" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §28');
Server.sendChat(spamsend + " " + "8" + " " + spamtext)
}
}
if(spam1==35)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §29');
Server.sendChat(spamsend + " " + "9" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §29');
Server.sendChat(spamsend + " " + "9" + " " + spamtext)
}
}
if(spam1==36)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §20');
Server.sendChat(spamsend + " " + "0" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §20');
Server.sendChat(spamsend + " " + "0" + " " + spamtext)
}
}
if(spam1==37)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2_');
Server.sendChat(spamsend + " " + "_" + " " + spamtext)
spam1=0;
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2_');
Server.sendChat(spamsend + " " + "_" + " " + spamtext)
spam1=0;
}
}
}

function spamq2()
{
if(spam2==50)
{
if(auth==true)	
{
Server.sendChat('/register 1234567890');
Server.sendChat('/login 1234567890');
}else{
}
}
if(spam2==100)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2q');
Server.sendChat(spamsend + " " + "q" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2q');
Server.sendChat(spamsend + " " + "q" + " " + spamtext)
}
}
if(spam2==150)
{
if(lang=="eng")
{	
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2w');
Server.sendChat(spamsend + " " + "w" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2w');
Server.sendChat(spamsend + " " + "w" + " " + spamtext)
}
}
if(spam2==200)
{
if(lang=="eng")
{		
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2e');
Server.sendChat(spamsend + " " + "e" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2e');
Server.sendChat(spamsend + " " + "e" + " " + spamtext)
}
}
if(spam2==250)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2r');
Server.sendChat(spamsend + " " + "r" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2r');
Server.sendChat(spamsend + " " + "r" + " " + spamtext)
}
}
if(spam2==300)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2t');
Server.sendChat(spamsend + " " + "t" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2t');
Server.sendChat(spamsend + " " + "t" + " " + spamtext)
}
}
if(spam2==350)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2y');
Server.sendChat(spamsend + " " + "y" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2y');
Server.sendChat(spamsend + " " + "y" + " " + spamtext)	
}
}
if(spam2==400)
{
if(lang=="eng")
{	
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2u');
Server.sendChat(spamsend + " " + "u" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2u');
Server.sendChat(spamsend + " " + "u" + " " + spamtext)
}
}
if(spam2==450)
{
if(lang=="eng")
{		
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2i');
Server.sendChat(spamsend + " " + "i" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2i');
Server.sendChat(spamsend + " " + "i" + " " + spamtext)
}
}
if(spam2==500)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2o');
Server.sendChat(spamsend + " " + "o" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6Отправка сообщения игроку, на букву - §2o');
Server.sendChat(spamsend + " " + "o" + " " + spamtext)	
}
}
if(spam2==550)
{
if(lang=="eng")
{				
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2p');
Server.sendChat(spamsend + " " + "p" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2p');
Server.sendChat(spamsend + " " + "p" + " " + spamtext)
}
}
if(spam2==600)
{
if(lang=="eng")
{				
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2a');
Server.sendChat(spamsend + " " + "a" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2a');
Server.sendChat(spamsend + " " + "a" + " " + spamtext)
}
}
if(spam2==650)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2s');
Server.sendChat(spamsend + " " + "s" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2s');
Server.sendChat(spamsend + " " + "s" + " " + spamtext)
}
}
if(spam2==700)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2d');
Server.sendChat(spamsend + " " + "d" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2d');
Server.sendChat(spamsend + " " + "d" + " " + spamtext)
}
}
if(spam2==750)
{
if(lang=="eng")
{				
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2f');
Server.sendChat(spamsend + " " + "f" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2f');
Server.sendChat(spamsend + " " + "f" + " " + spamtext)
}
}
if(spam2==800)
{
if(lang=="eng")
{				
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2g');
Server.sendChat(spamsend + " " + "g" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2g');
Server.sendChat(spamsend + " " + "g" + " " + spamtext)
}
}
if(spam2==850)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2h');
Server.sendChat(spamsend + " " + "h" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2h');
Server.sendChat(spamsend + " " + "h" + " " + spamtext)
}
}
if(spam2==900)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2j');
Server.sendChat(spamsend + " " + "j" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2j');
Server.sendChat(spamsend + " " + "j" + " " + spamtext)
}
}
if(spam2==950)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2k');
Server.sendChat(spamsend + " " + "k" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2k');
Server.sendChat(spamsend + " " + "k" + " " + spamtext)
}
}
if(spam2==1000)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2l');
Server.sendChat(spamsend + " " + "l" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2l');
Server.sendChat(spamsend + " " + "l" + " " + spamtext)
}
}
if(spam2==1050)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2z');
Server.sendChat(spamsend + " " + "z" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2z');
Server.sendChat(spamsend + " " + "z" + " " + spamtext)
}
}
if(spam2==1100)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2x');
Server.sendChat(spamsend + " " + "x" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2x');
Server.sendChat(spamsend + " " + "x" + " " + spamtext)
}
}
if(spam2==1150)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2c');
Server.sendChat(spamsend + " " + "c" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2c');
Server.sendChat(spamsend + " " + "c" + " " + spamtext)
}
}
if(spam2==1200)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2v');
Server.sendChat(spamsend + " " + "v" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2v');
Server.sendChat(spamsend + " " + "v" + " " + spamtext)		
}
}
if(spam2==1250)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2b');
Server.sendChat(spamsend + " " + "b" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2b');
Server.sendChat(spamsend + " " + "b" + " " + spamtext)
}
}
if(spam2==1300)
{
if(lang=="eng")
{				
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2n');
Server.sendChat(spamsend + " " + "n" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2n');
Server.sendChat(spamsend + " " + "n" + " " + spamtext)
}
}
if(spam2==1350)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2m');
Server.sendChat(spamsend + " " + "m" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2m');
Server.sendChat(spamsend + " " + "m" + " " + spamtext)
}
}
if(spam2==1400)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §21');
Server.sendChat(spamsend + " " + "1" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §21');
Server.sendChat(spamsend + " " + "1" + " " + spamtext)
}
}
if(spam2==1450)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §22');
Server.sendChat(spamsend + " " + "2" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §22');
Server.sendChat(spamsend + " " + "2" + " " + spamtext)
}
}
if(spam2==1500)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §23');
Server.sendChat(spamsend + " " + "3" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §23');
Server.sendChat(spamsend + " " + "3" + " " + spamtext)
}
}
if(spam2==1550)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §24');
Server.sendChat(spamsend + " " + "4" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §24');
Server.sendChat(spamsend + " " + "4" + " " + spamtext)
}
}
if(spam2==1600)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §25');
Server.sendChat(spamsend + " " + "5" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §25');
Server.sendChat(spamsend + " " + "5" + " " + spamtext)
}
}
if(spam2==1650)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §26');
Server.sendChat(spamsend + " " + "6" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §26');
Server.sendChat(spamsend + " " + "6" + " " + spamtext)
}
}
if(spam2==1700)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §27');
Server.sendChat(spamsend + " " + "7" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §27');
Server.sendChat(spamsend + " " + "7" + " " + spamtext)
}
}
if(spam2==1750)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §28');
Server.sendChat(spamsend + " " + "8" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §28');
Server.sendChat(spamsend + " " + "8" + " " + spamtext)
}
}
if(spam2==1800)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §29');
Server.sendChat(spamsend + " " + "9" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §29');
Server.sendChat(spamsend + " " + "9" + " " + spamtext)
}
}
if(spam2==1850)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §20');
Server.sendChat(spamsend + " " + "0" + " " + spamtext)
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §20');
Server.sendChat(spamsend + " " + "0" + " " + spamtext)
}
}
if(spam2==1900)
{
if(lang=="eng")
{			
clientMessage('§7(Kiellt) §6Spam player starts with the letter - §2_');
Server.sendChat(spamsend + " " + "_" + " " + spamtext)
spam2=0;
}else{
clientMessage('§7(Kiellt) §6 Отправка сообщения игроку, на букву - §2_');
Server.sendChat(spamsend + " " + "_" + " " + spamtext)
spam2=0;
}
}
}

function spamq3()
{
if(spam3==0)
{
if(auth==true)	
{
Server.sendChat('/register 1234567890');
Server.sendChat('/login 1234567890');
}else{
if(trr==true)
{
Server.sendChat(""+replacetext(spamtext));
}else{
Server.sendChat(spamtext);
}
}
}
if(spam3==spam3zad)
{
if(trr==true)
{
Server.sendChat(""+replacetext(spamtext));
}else{
Server.sendChat(spamtext);
}
spam3=0;
}
}

function spamq4()
{
if(spam4==50)
{
if(auth==true)	
{
Server.sendChat('/register 1234567890');
Server.sendChat('/login 1234567890');
}else{
if(trr==true)
{
Server.sendChat(""+replacetext(spamtext));
}else{
Server.sendChat(spamtext);
}
}
}
if(spam4==100)
{
if(trr==true)
{
Server.sendChat(""+replacetext(spamtext));
}else{
Server.sendChat(spamtext);
}
spam4=0;	
}
}

function spamq6()
{
if(spam6==1)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2sent teams: §6' + homes + ".");
Server.sendChat('/sethome kbcddyuuhgfrhfjgxfhvftgdshfdtgcfrtyijvcdrygdseffcd' + homes);
spam6=0;
}else{
clientMessage('§7(Kiellt) §2Отправлено команд: §6' + homes + ".");
Server.sendChat('/sethome ' + homes);
spam6=0;
}
}
}

function spamq5()
{
if(spam5==20)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2Password: §712345' + '.')
Server.sendChat(passcom + "12345");
}else{
clientMessage('§7(Kiellt) §2Пароль: §712345' + '.')
Server.sendChat(passcom + "12345");
}
}
if(spam5==40)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2Password: §7123456' + '.')
Server.sendChat(passcom + "123456");
}else{
clientMessage('§7(Kiellt) §2Пароль: §7123456' + '.')
Server.sendChat(passcom + "123456");
}
}
if(spam5==60)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2Password: §71234567' + '.')
Server.sendChat(passcom + "1234567");
}else{
clientMessage('§7(Kiellt) §2Пароль: §71234567' + '.')
Server.sendChat(passcom + "1234567");
}
}
if(spam5==80)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2Password: §712345678' + '.')
Server.sendChat(passcom + "12345678");
}else{
clientMessage('§7(Kiellt) §2Пароль: §712345678' + '.')
Server.sendChat(passcom + "12345678");
}
}
if(spam5==100)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2Password: §7123456789' + '.')
Server.sendChat(passcom + "123456789");
}else{
clientMessage('§7(Kiellt) §2Пароль: §7123456789' + '.')
Server.sendChat(passcom + "123456789");
}
}
if(spam5==120)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2Password: §71234567890' + '.')
Server.sendChat(passcom + "1234567890");
}else{
clientMessage('§7(Kiellt) §2Пароль: §71234567890' + '.')
Server.sendChat(passcom + "1234567890");
}
}
if(spam5==140)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2Password: §7123123' + '.')
Server.sendChat(passcom + "123123");
}else{
clientMessage('§7(Kiellt) §2Пароль: §7123123' + '.')
Server.sendChat(passcom + "123123");
}
}
if(spam5==160)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2Password: §712341234' + '.')
Server.sendChat(passcom + "12341234");
}else{
clientMessage('§7(Kiellt) §2Пароль: §712341234' + '.')
Server.sendChat(passcom + "12341234");
}
}
if(spam5==180)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2Password: §71234512345' + '.')
Server.sendChat(passcom + "1234512345");
}else{
clientMessage('§7(Kiellt) §2Пароль: §71234512345' + '.')
Server.sendChat(passcom + "1234512345");
}
}
if(spam5==200)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2Password: §7321321' + '.')
Server.sendChat(passcom + "321321");
}else{
clientMessage('§7(Kiellt) §2Пароль: §7321321' + '.')
Server.sendChat(passcom + "321321");
}
}
if(spam5==220)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2Password: §7qwerty' + '.')
Server.sendChat(passcom + "qwerty");
}else{
clientMessage('§7(Kiellt) §2Пароль: §7qwerty' + '.')
Server.sendChat(passcom + "qwerty");
}
}
if(spam5==240)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2Password: §7qwertyu' + '.')
Server.sendChat(passcom + "qwertyu");
}else{
clientMessage('§7(Kiellt) §2Пароль: §7qwertyu' + '.')
Server.sendChat(passcom + "qwertyu");
}
}
if(spam5==260)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2Password: §7qwertyui' + '.')
Server.sendChat(passcom + "qwertyui");
}else{
clientMessage('§7(Kiellt) §2Пароль: §7qwertyui' + '.')
Server.sendChat(passcom + "qwertyui");
}
}
if(spam5==280)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2Password: §7qwertyuio' + '.')
Server.sendChat(passcom + "qwertyuio");
}else{
clientMessage('§7(Kiellt) §2Пароль: §7qwertyuio' + '.')
Server.sendChat(passcom + "qwertyuio");
}
}
if(spam5==300)
{
if(lang=="eng")
{
clientMessage('§7(Kiellt) §2Password: §7qwertyuiop' + '.')
Server.sendChat(passcom + "qwertyuiop");
}else{
clientMessage('§7(Kiellt) §2Пароль: §7qwertyuiop' + '.')
Server.sendChat(passcom + "qwertyuiop");
spam5=0;
}
}
}

var FileNotFoundException = java.io.FileNotFoundException;

function hack()
{
if(hacktime==hacktime)
{
try{
if(file.readLine(base, hacktime)==null)
{
hacktick=false;
if(lang=="eng")
{
clientMessage("§7 (Kiellt) §6Auto password selection is complete.");
}else{
clientMessage("§7(Kiellt) §6Авто-подбор паролей закончен.");
}
}
if(lang=="eng")
{
clientMessage("§7(Kiellt) §6Password: §2" + file.readLine(base, hacktime) + "§6.");
}else{
clientMessage("§7(Kiellt) §6Пароль: §2" + file.readLine(base, hacktime) + "§6.");
}
Server.sendChat(basemsg + file.readLine(base, hacktime));
}catch(e){
if(lang=="eng")
{
clientMessage("§7(Kiellt) §cError. The file 'base.txt' is not found in the folder: §6/games/com.mojang/minecraftpe§c.");
}else{
clientMessage("§7(Kiellt) §cОшибка. Файл 'base.txt' не найден в папке: §6/games/com.mojang/minecraftpe§c.");
}
}
}
}

var base = file.select(sdcard + '/games/com.mojang/minecraftpe','base.txt')

function bowAimAt(ent) {
			var velocity = 1;
			var posX = Entity.getX(ent) - Player.getX();
			var posY = Entity.getEntityTypeId(ent) == EntityType.PLAYER ? Entity.getY(ent) - Player.getY() : Entity.getY(ent) + 1 - Player.getY();
			var posZ = Entity.getZ(ent) - Player.getZ();
			var yaw = (Math.atan2(posZ, posX) * 180 / Math.PI) - 90;
			var y2 = Math.sqrt(posX * posX + posZ * posZ);
			var g = 0.007;
			var tmp = (velocity * velocity * velocity * velocity - g * (g * (y2 * y2) + 2 * posY * (velocity * velocity)));
			var pitch = -(180 / Math.PI) * (Math.atan((velocity * velocity - Math.sqrt(tmp)) / (g * y2)));
			if(pitch < 89 && pitch > -89) {
				setRot(Player.getEntity(), yaw, pitch);
			}
		}
		
function getNearestEntity(maxrange) {
			var mobs = Entity.getAll();
			var players = Server.getAllPlayers();
			var small = maxrange;
			var ent = null;
			for (var i = 0; i < mobs.length; i++) {
				var x = Entity.getX(mobs[i]) - getPlayerX();
				var y = Entity.getY(mobs[i]) - getPlayerY();
				var z = Entity.getZ(mobs[i]) - getPlayerZ();
				var dist = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2) + Math.pow(z, 2));
				if (dist < small && dist > 0 && Entity.getEntityTypeId(mobs[i]) <= 63 && Entity.getHealth(mobs[i]) >= 1) {
					small = dist;
					ent = mobs[i];
				}
			}
			for (var i = 0; i < players.length; i++) {
				var x = Entity.getX(players[i]) - getPlayerX();
				var y = Entity.getY(players[i]) - getPlayerY();
				var z = Entity.getZ(players[i]) - getPlayerZ();
				var dist = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2) + Math.pow(z, 2));
				if (dist < small && dist > 0 && Entity.getHealth(players[i]) >= 1) {
					small = dist;
					ent = players[i];
				}
			}
			return ent;
		}		
		
var s1 = true;
var s2 = false;		
var bhopt = 0;
var bhopd = false;
var hhj = 0;

function jetpackTick() {
    toDirectionalVector(playerDir, (getYaw() + 90) * DEG_TO_RAD, getPitch() * DEG_TO_RAD * -1);
    var player = getPlayerEnt();
    setVelX(player, playerFlySpeed * playerDir[0]);
    setVelY(player, playerFlySpeed * playerDir[1]);
    setVelZ(player, playerFlySpeed * playerDir[2]);
}
 
function toDirectionalVector(vector, yaw, pitch) {
    vector[0] = Math.cos(yaw) * Math.cos(pitch);
    vector[1] = Math.sin(pitch);
    vector[2] = Math.sin(yaw) * Math.cos(pitch);
}

function entityHurtHook(att, vic, hearts) {
			if (antiknockback || ( vic != p)) {
			return;
		Entity.setImmobile(getPlayerEnt, true);
		this.attackTick = 2;
	 }
	}
	
function messagechat()
{
if(!Launcher.ismcpe())
{
if(messagechats==2400)
{
clientMessage("§7(Kiellt) §aПодписывайтесь на нашу группу ВК: §6vk.com/cheat_kiellt§a.")
messagechats=0;
}
}
}


var context = com['mojang']['minecraftpe']['MainActivity']['currentMainActivity']['get']();
var ccc = com['mojang']['minecraftpe']['MainActivity']['currentMainActivity']['get']();

function textforspam()
{
    var win1 = new android['widget'].LinearLayout(ccc);
    win1['setGravity'](android['view']['Gravity'].CENTER);
    win1['setOrientation'](android['widget']['LinearLayout'].VERTICAL);
    var wind1 = new android['widget'].EditText(ccc);
if(lang=="eng")
{
wind1['setHint']('Text for spam');
}else{
wind1['setHint']('Текст для спама');
}
    
    var windo1 = new android['widget'].ScrollView(ccc);
    var window1 = new android['widget'].Button(ccc);
if(lang=="eng")
{
window1['setText']('Save');
}else{
window1['setText']('Сохранить');
}
    
    
    window1['setOnClickListener'](new android['view']['View'].OnClickListener(
    {
        onClick: function (viewarg)
        {
spamtext = wind1.getText();
if(lang=="eng")
{
clientMessage("§7[Kiellt] §2: §6The text of the spam has been successfully changed to: §6'" + spamtext + "'.");
print("Done.");
}else{
clientMessage("§7[Kiellt] §2§lТекст для спама был успешно изменён на: §6'" + spamtext + "'.");
print("Готово!");
}
        }
    }));    
    var windows1 = new android['app']['AlertDialog'].Builder(ccc);
if(lang=="eng") 
{
windows1['setTitle']('Edit text for spam');
}else{
windows1['setTitle']('Изменить текст для спама');
}
    win1['addView'](wind1);
    win1['addView'](window1);
    win1['addView'](windo1);
    windows1['setView'](win1);
    windows1['create']()['show']();
}  

function effects()
{
    var win2 = new android['widget'].LinearLayout(ccc);
    win2['setGravity'](android['view']['Gravity'].CENTER);
    win2['setOrientation'](android['widget']['LinearLayout'].VERTICAL);
    var wind2 = new android['widget'].EditText(ccc);
if(lang=="eng")
{
    wind2['setHint']("ID effect");
    }
    else{
    	wind2['setHint']("ID эффекта");
    }
    var wind2s1 = new android['widget'].EditText(ccc);
    if(lang=="eng")
    {
    wind2s1['setHint']("Duration of effect");    
    }else{
    wind2s1['setHint']("Продолжительность эффекта");  	
    }
    var wind2s2 = new android['widget'].EditText(ccc);
    if(lang=='eng')
    {
    wind2s2['setHint']("The effect of the force");    
    }else{
    	wind2s2['setHint']("Сила эффекта");   
    }
    var windo2 = new android['widget'].ScrollView(ccc);
    var window2 = new android['widget'].Button(ccc);
    if(lang=='eng')
    {
    window2['setText']('Give Effect');
    }else{
    	window2['setText']('Выдать эффект');
    }
    
    window2['setOnClickListener'](new android['view']['View'].OnClickListener(
    {
        onClick: function (viewarg)
        {
Entity.addEffect(getPlayerEnt(), wind2.getText().toString() , wind2s1.getText().toString(), wind2s2.getText().toString(), true, false); 
        }
    }));   
    var windows2 = new android['app']['AlertDialog'].Builder(ccc);
if(lang=="eng")
{
    windows2['setTitle']("Hack effect");
}else{
    windows2['setTitle']("Взлом эффектов");
}
    win2['addView'](wind2);
    win2['addView'](wind2s1);
    win2['addView'](wind2s2);
    win2['addView'](window2);   
    win2['addView'](windo2);
    windows2['setView'](win2);   
    windows2['create']()['show']();
}        

function textspam2()
{
    var win2 = new android['widget'].LinearLayout(ccc);
    win2['setGravity'](android['view']['Gravity'].CENTER);
    win2['setOrientation'](android['widget']['LinearLayout'].VERTICAL);
    var wind2 = new android['widget'].EditText(ccc);
if(lang=="eng")
{
    wind2['setHint']("1 text");
    }
    else{
    	wind2['setHint']("1 текст");
    }
    var wind2s1 = new android['widget'].EditText(ccc);
    if(lang=="eng")
    {
    wind2s1['setHint']("2 text");    
    }else{
    wind2s1['setHint']("2 текст");  	
    }
    var windo2 = new android['widget'].ScrollView(ccc);
    var window2 = new android['widget'].Button(ccc);
    if(lang=='eng')
    {
    window2['setText']('Save');
    }else{
    	window2['setText']('Сохранить');
    }
    
    window2['setOnClickListener'](new android['view']['View'].OnClickListener(
    {
        onClick: function (viewarg)
        {
spam2chattext = wind2.getText();
spam2chattext2 = wind2s1.getText();
if(lang=="eng")
{
print("Done.")
}else{
print("Готово.")
}
        }
    }));   
    var windows2 = new android['app']['AlertDialog'].Builder(ccc);
if(lang=="eng")
{
    windows2['setTitle']("Change text for .spamchat2");
}else{
    windows2['setTitle']("Изменить текст для .spamchat2");
}
    win2['addView'](wind2);
    win2['addView'](wind2s1);
    win2['addView'](window2);   
    win2['addView'](windo2);
    windows2['setView'](win2);   
    windows2['create']()['show']();
}        

function changecolormenu()
{
var win3 = new android['widget'].LinearLayout(ccc);
    win3['setGravity'](android['view']['Gravity'].CENTER);
    win3['setOrientation'](android['widget']['LinearLayout'].VERTICAL);
    var wind3 = new android['widget'].EditText(ccc);
if(lang=="eng")
{
    wind3['setHint']("The first value");
    }
    else{
    	wind3['setHint']("Первое значение");
    }
    var wind3s1 = new android['widget'].EditText(ccc);
    if(lang=="eng")
    {
    wind3s1['setHint']("The second value");    
    }else{
    wind3s1['setHint']("Второе значение");  	
    }
    var wind3s2 = new android['widget'].EditText(ccc);
    if(lang=="eng")
    {
    wind3s2['setHint']("Third value");    
    }else{
    wind3s2['setHint']("Третье значение");  	
    }    
    var wind3s3 = new android['widget'].EditText(ccc);
    if(lang=="eng")
    {
    wind3s3['setHint']("Fourth value");    
    }else{
    wind3s3['setHint']("Четвёртое значение");  	
    }        
    var windo3 = new android['widget'].ScrollView(ccc);
    var window3 = new android['widget'].Button(ccc);
    if(lang=='eng')
    {
    window3['setText']('Save');
    }else{
    	window3['setText']('Сохранить');
    }
    
    window3['setOnClickListener'](new android['view']['View'].OnClickListener(
    {
        onClick: function (viewarg)
        {
    
colorj = android.graphics.Color.argb(wind3.getText(), wind3s1.getText(), wind3s2.getText(), wind3s3.getText());
        }
    }));   
    var windows3 = new android['app']['AlertDialog'].Builder(ccc);
if(lang=="eng")
{
    windows3['setTitle']("Change the color of the menu");
}else{
    windows3['setTitle']("Изменить цвет меню");
}
    win3['addView'](wind3);
    win3['addView'](wind3s1);
    win3['addView'](wind3s2);
    win3['addView'](wind3s3);
    win3['addView'](window3);   
    win3['addView'](windo3);
    windows3['setView'](win3);   
    windows3['create']()['show']();
}

function trollchat()
{
var win4 = new android['widget'].LinearLayout(ccc);
    win4['setGravity'](android['view']['Gravity'].CENTER);
    win4['setOrientation'](android['widget']['LinearLayout'].VERTICAL);
    var wind4 = new android['widget'].EditText(ccc);
if(lang=="eng")
{
    wind4['setText']("Text.");
    }
    else{
    	wind4['setText']("Текст.");
    }
    var windo4 = new android['widget'].ScrollView(ccc);
    var window4 = new android['widget'].Button(ccc);
    if(lang=='eng')
    {
    window4['setText']('Send');
    }else{
    	window4['setText']('Отправить');
    }
    
    window4['setOnClickListener'](new android['view']['View'].OnClickListener(
    {
        onClick: function (viewarg)
        {
clientMessage(wind4.getText())
        }
    }));   
    var windows4 = new android['app']['AlertDialog'].Builder(ccc);
if(lang=="eng")
{
    windows4['setTitle']("Troll Chat");
}else{
    windows4['setTitle']("Тролл Чат");
}
    win4['addView'](wind4);
    win4['addView'](window4);   
    win4['addView'](windo4);
    windows4['setView'](win4);   
    windows4['create']()['show']();
}

function mcped()
{
if(ticklaj==1)
new android.os.Handler().postDelayed(new java.lang.Runnable({run: function() {
modTick();
}
}), 0);
}

function modTick()   
{
if(Launcher.ismcpe())
{
mcped();
}
if(tapattack==true)
{
Entity.setCollisionSize(true, 12, 12);
}
if(dasd==1)
{
setVelX(getPlayerEnt(), Entity.getVelX(getPlayerEnt())*2);
					setVelZ(getPlayerEnt(), Entity.getVelZ(getPlayerEnt())*2)
}
if(dasd==2)
{
setVelX(getPlayerEnt(), Entity.getVelX(getPlayerEnt())*3);
					setVelZ(getPlayerEnt(), Entity.getVelZ(getPlayerEnt())*3)
}
if(dasd==3)
{
setVelX(getPlayerEnt(), Entity.getVelX(getPlayerEnt())*4);
					setVelZ(getPlayerEnt(), Entity.getVelZ(getPlayerEnt())*4)
}
if(dasd==4)
{
setVelX(getPlayerEnt(), Entity.getVelX(getPlayerEnt())*5);
					setVelZ(getPlayerEnt(), Entity.getVelZ(getPlayerEnt())*5)
}
if(flyg==true)
{
Entity.setVelY(getPlayerEnt(), 0.0)
}
if(antihealth==true)
{
Player.setHealth(20);
}
if(antihanger==true)
{
Player.setHunger(20);
}
if(hacktick==true)
{
hacktime++;
hack()
}
if(ddooss==true)
{
numberpackets++; 
if(lang == "eng")
{
clientMessage("§7(Kiellt) §6Sent packages: §2" + numberpackets);
}else{
clientMessage("§7(Kiellt) §6Отправлено пакетов: §2" + numberpackets);
}
gl(serverl);
}
if(bhopd==true)
{
bhopt++;
}
if(bhop==true)
{
if(bhopt==5)
{
setVelY(getPlayerEnt(), 0.5);
bhopt++;
}
if(bhopt==10)
{
setVelY(getPlayerEnt(), -0.5);
bhopt=0;
}
}
if(messagechatss==true)
{
messagechats++;
messagechat()
}
if(autoenchant==true)
{
Player.enchant(Player.getSelectedSlotId(), Enchantment.EFFICIENCY,1000);
      Player.enchant(Player.getSelectedSlotId(), Enchantment.INFINITY,1000);
       Player.enchant(Player.getSelectedSlotId(), Enchantment.SMITE,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.DEPTH_STRIDER,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.FIRE_ASPECT,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.FORTUNE,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.FLAME,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.SHARPNESS,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.LOOTING,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.KNOCKBACK,1000);
Player.enchant(Player.getSelectedSlotId(), Enchantment.UNBREAKING,1000);
}
if(flyff==true)
{
Entity.setVelY(getPlayerEnt(), -0.0)
}
if(autol==true)
{
if(Entity.getHealth(Player.getEntity()) == 1) 
{
ModPE.leaveGame();
}
if(Entity.getHealth(Player.getEntity()) == 2) 
{
ModPE.leaveGame();
}
if(Entity.getHealth(Player.getEntity()) == 3) 
{
ModPE.leaveGame();
}
if(Entity.getHealth(Player.getEntity()) == 4) 
{
ModPE.leaveGame();
}
}
if(noeffects == true)
{
Entity.removeAllEffects(getPlayerEnt());
}
if(autowalk==true)
{
	            toDirectionalVector(playerDir, (getYaw() + 90) * DEG_TO_RAD, getPitch() * DEG_TO_RAD * -1);
        setVelX(getPlayerEnt(), 0.22 * playerDir[0]);
        setVelZ(getPlayerEnt(), 0.22 * playerDir[2]);
}
if (bowaimbot && getCarriedItem() == 261) {
var ent = getNearestEntity(50);
if(ent != null) {
                            bowAimAt(ent);
                            
}else {
                                bowaim = true;
}
}
if (bowaim) {						
}	

if (antiknockback || Entity.getHealth(getPlayerEnt()) <= 0) {
		   if(this.tick > 0) {
           tick--;
		} else {
			Entity.setImmobile(getPlayerEnt(), false);
		}
		if(this.health > Entity.getHealth(getPlayerEnt())){
			Entity.setImmobile(getPlayerEnt(), true);
			this.tick = 1;
		}
		this.tick = 0;
		this.health = Entity.getHealth(getPlayerEnt());
	}	
if (spam1on==true)
{
spam1++;
spamq1();
}
if (spam2on==true)
{
spam2++;
spamq2();
}
if (spam3on==true)
{
spam3++;
spamq3();
}
if (spam4on==true)
{
spam4++;
spamq4();
}
if (spam5on==true)
{
spam5++;
spamq5();
}
if (spam6on==true)
{
spam6++;
spamq6();
}
if (spam7on==true)
{
spam7++;
spamq7();
}
if (spam8on==true)
{
spam8++;
spamq8();
}
if (home==true)
{
homes++;
}
if (opnicks==true)
{
opnick++;
}
if(showhp==true)
{
if(lang=="eng"){    	
ModPE.showTipMessage('\n\n§7(Kiellt) §5HP: §6' + Entity.getHealth(Player.getEntity()))
}else{
ModPE.showTipMessage('\n\n§7§l(Kiellt) §5ХП: §6' + Entity.getHealth(Player.getEntity()))
}
}
if(step==true)
{
if(stepf())
setPosition(getPlayerEnt(), Player.getX(), Player.getY() + 1.04, Player.getZ())
if(stepf())
setVelY(getPlayerEnt(), 0.4);
}
if(autosp==true)
{
if(Entity.getHealth(Player.getEntity()) == 1) 
{
Server.sendChat("/spawn");
}
if(Entity.getHealth(Player.getEntity()) == 2) 
{
Server.sendChat("/spawn");
}
if(Entity.getHealth(Player.getEntity()) == 3) 
{
Server.sendChat("/spawn");
}
if(Entity.getHealth(Player.getEntity()) == 4) 
{
Server.sendChat("/spawn");
}
}
if(glide==true)
{
if(glidest1==1)
{
setVelY(getPlayerEnt(),-0.10);
}
}
if(vsr==true)
{
setTile(getPlayerX(),getPlayerY()-2,getPlayerZ(),blockid1)
}
if(sdh==true)
{
if(sdhst1==1)
{
if(s==1)
{
Xpos=getPlayerX();
Zpos=getPlayerZ();
s = s + 1;
}
else if(s==3)
{
s=1;
Xdiff=getPlayerX()-Xpos;
Zdiff=getPlayerZ()-Zpos;
setVelX(getPlayerEnt(),Xdiff);
setVelZ(getPlayerEnt(),Zdiff);
Xdiff=0;
Zdiff=0;
}
if(s!=1)
{
s = s + 1;
}
}
}
if(aus==true)
{
clientMessage('/sethome 1')	
}
if(wtw==true)
{
if(wtwst1==1)
{
		if(Level.getTile(getPlayerX(), getPlayerY() - 2, getPlayerZ()) == 8 || Level.getTile(getPlayerX(), getPlayerY() - 2, getPlayerZ()) == 9 || Level.getTile(getPlayerX(), getPlayerY() - 2, getPlayerZ()) == 10 || Level.getTile(getPlayerX(), getPlayerY() - 2, getPlayerZ()) == 11) {
			setVelY(Player.getEntity(), 0);		
}
}
}
if(nwls==true)
{
Entity.setCollisionSize(getPlayerEnt(),0,0);
		if(Level.getTile(Player.getX(),Player.getY(), Player.getZ())!=0 && Level.getTile(Player.getX(),Player.getY()-1, Player.getZ())!=0) {
			setVelY(getPlayerEnt(), 0.01);
		}
}
if(eday==true)
{
Level.setTime(2000);
}
if(jtp==true)
{
jetpackTick();
}
						if (killaura == true) {
							var mobs = Entity.getAll();
							var players = Server.getAllPlayers();
							var small = 10;
							var ent = null;
							for (var i = 0; i < mobs.length; i++) {
								var x = Entity.getX(mobs[i]) - getPlayerX();
								var y = Entity.getY(mobs[i]) - getPlayerY();
								var z = Entity.getZ(mobs[i]) - getPlayerZ();
								var dist = Math.sqrt(Math.pow(x,2) + Math.pow(y,2) + Math.pow(z,2));
								if(dist < small && dist > 0 && Entity.getEntityTypeId(mobs[i]) <= 63 && Entity.getHealth(mobs[i]) >= 1){
									small = dist;
									ent = mobs[i];
								}
							}
							for (var i = 0; i < players.length; i++) {
								var x = Entity.getX(players[i]) - getPlayerX();
								var y = Entity.getY(players[i]) - getPlayerY();
								var z = Entity.getZ(players[i]) - getPlayerZ();
								var dist = Math.sqrt(Math.pow(x,2) + Math.pow(y,2) + Math.pow(z,2));
								if(dist < small && dist > 0 && Entity.getHealth(players[i]) >= 1){
									small = dist;
									ent = players[i];
								}
							}
							if(ent != null){
								var x = Entity.getX(ent) - getPlayerX();
								var y = Entity.getY(ent) - getPlayerY();
								var z = Entity.getZ(ent) - getPlayerZ();
								if(Entity.getEntityTypeId(ent) != 63)
									y += 0.5;
								var a = 0.5 + Entity.getX(ent);
								var b = Entity.getY(ent);
								var c = 0.5 + Entity.getZ(ent);
								var len = Math.sqrt(x * x + y * y + z * z);
								var y = y / len;
								var pitch = Math.asin(y);
								pitch = pitch * 180.0 / Math.PI;
								pitch = -pitch;
								if (pitch < 90 && pitch > -90) {										
									Entity.setRot(Player.getEntity(), -Math.atan2(a - (Player.getX() + 0.5), c - (Player.getZ() + 0.5)) * (180 / Math.PI), pitch);
								}
							}
								if (x * x + y * y + z * z <= 9 * 9 && x * x + y * y + z * z >= 0.001 && mobs[i] !== Player.getEntity() ) {									
								}
								}
}   