var sho=[]
a=false
p=1705
l=1706
dc=1707
ModPE.setItem(p,"m92f",0,"m92f",1);
//Item.setHandEquipped(p,true);
Player.addItemCreativeInv(p,1);
Item.addShapedRecipe(p,1,0,[
"mmm",
"ppp",
"bmm"],
["p",331,0,"b",266,0,"m",265,0]);
ModPE.setItem(l,"がば",0,"M1911A1",1);
Player.addItemCreativeInv(l,1);
//Item.setHandEquipped(l,true);
Item.addShapedRecipe(l,1,0,[
"mmm",
"ppp",
"bmm"],
["p",331,0,"b",266,0,"m",265,0]);
ModPE.setItem(dc,"ハンドガン",0,"Clip",64);
Player.addItemInventory(dc,64);
Player.addItemCreativeInv(dc,64);
Item.addShapedRecipe(dc,1,0,[
"   ",
" b ",
" o "],
["b",289,0,"o",265,0]);

b=0
ca=true
no=true
re=false

function modTick(){
if(re==false&&gon==0){
  ctx.runOnUiThread(runnable3);
re=true
}



if(Player.getCarriedItem()!=p&&ca==false){
 box()
   ctx.runOnUiThread(
new java.lang.Runnable(
{run:function(){
 try{
popupWindow3.dismiss()
}catch(e){
clientMessage(e)
}}}));

ca=true
}

if(Player.getCarriedItem()!=l&&no==false){
box()
   ctx.runOnUiThread(
new java.lang.Runnable(
{run:function(){
 try{
popupWindow3.dismiss()
}catch(e){
clientMessage(e)
}}}));
no=true
}
if(Player.getCarriedItem()==p&&ca==true){
  ctx.runOnUiThread(runnable);
  ctx.runOnUiThread(runnables);
if(ProgressBar.getProgress()==0){
  ctx.runOnUiThread(runnable3);
}
ca=false
}
if(Player.getCarriedItem()==l&&no==true){
  ctx.runOnUiThread(runnable);
  ctx.runOnUiThread(runnables);
if(ProgressBar.getProgress()==0){
  ctx.runOnUiThread(runnable3);
}
no=false

}


}
function leaveGame(){
box();
ca=true
no=true
}
var gon=12
var mond=0
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
var button = new android.widget.Button(ctx);
button.setText("Shoot")
button.setOnClickListener(new android.view.View.OnClickListener({onClick:function(viewarg){
if(Player.getCarriedItem()==p||Player.getCarriedItem()==l){
atk=11
}
if(gon>0){
var x=Player.getX();
var y=Player.getY()-1;
var z=Player.getZ();

playerYaw = Entity.getYaw(Player.getEntity());
playerPitch = Entity.getPitch(Player.getEntity()); 
velY = Math.sin((playerPitch - 180) / 180 * Math.PI); 
velX =Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI); 
velZ =-1 * Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI); 
var Canon = Level.spawnMob(x + Math.sin(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,y+1,z-1* Math.cos(playerYaw / 180 * Math.PI) * Math.cos((playerPitch - 180) / 180 * Math.PI) ,80);
setVelX(Canon,velX*atk); 
setVelY(Canon,velY*atk); 
setVelZ(Canon,velZ*atk); 
gon=gon-1
var playerYaw = Entity.getYaw(Player.getEntity());
var playerPitch = Entity.getPitch(Player.getEntity()); 
Entity.setRot(Player.getEntity(),playerYaw,playerPitch-1);
Level.playSound(x,y,z,"random.explode",100,1.2);  
ProgressBar.setProgress(ProgressBar.getProgress()-1);
}}
}));



var popupWindow =  new android.widget.PopupWindow(button, 200,100);


var runnable = new java.lang.Runnable(

 {run:function(){

   popupWindow.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.CENTER|android.view.Gravity.RIGHT,0,0);
 }}
);

function box(){
   ctx.runOnUiThread(
new java.lang.Runnable(
{run:function(){
 try{
popupWindow.dismiss()
popupWindow2.dismiss()
}catch(e){
clientMessage(e)
}}}));
}


var ProgressBar = android.widget.ProgressBar(ctx,null, android.R.attr.progressBarStyleHorizontal);
        ProgressBar.setMax(12);
        ProgressBar.setProgress(gon);
        
var popupWindow2 =  new android.widget.PopupWindow(ProgressBar, 400, 400);


var runnables = new java.lang.Runnable(

 {run:function(){
   popupWindow2.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP|android.view.Gravity.RIGHT, 0, 50);
 }}
);



var button2 = new android.widget.Button(ctx);
button2.setText("Reload")
button2.setOnClickListener(new android.view.View.OnClickListener({onClick:function(viewarg){
for(var vnm=0;vnm<=44;vnm++){
if(Player.getInventorySlot(vnm)==dc){
        ProgressBar.setProgress(12);
gon=12
re=false
var x=Player.getX();
var y=Player.getY();
var z=Player.getZ();
Level.playSound(x,y,z,"random.door_close",100,0.6);  
Player.setInventorySlot(vnm,dc,Player.getInventorySlotCount(vnm)-1,0);
   ctx.runOnUiThread(
new java.lang.Runnable(
{run:function(){
 try{
popupWindow3.dismiss()
}catch(e){
clientMessage(e)
}}}));
break;
}}
}}));
var popupWindow3 =  new android.widget.PopupWindow(button2, 200,100);


var runnable3 = new java.lang.Runnable(

 {run:function(){

   popupWindow3.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.CENTER|android.view.Gravity.RIGHT,0,100);
 }}
);
